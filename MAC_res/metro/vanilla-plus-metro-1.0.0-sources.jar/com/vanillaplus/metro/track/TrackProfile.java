package com.vanillaplus.metro.track;

import net.minecraft.class_2246;
import net.minecraft.class_2680;

/**
 * 参数化的轨道横截面模板。
 *
 * 生成器（{@link TrackBuilder}）用"盖章 + 抠壳"的方式沿中心线施工，因此这里只描述"走廊"的参数，
 * 而不是逐格坐标——从而直线、坡道、拐角都能共用同一套逻辑：
 *  - halfWidth / height：内部净空的半宽与高度（隧道会开挖成这么大的通道；开顶样式则是净空+桥面宽度）。
 *  - floor：轨道下方 (dy=-1) 铺满的方块。
 *  - enclosed + wall + ceiling：封闭样式（隧道）会围墙+盖顶；墙壳由内腔边界自动抠出，拐角天然包严。
 *  - wall + railHeight（开顶样式）：桥面/路基边缘的护栏及其高度。
 *  - light / lightSpacing：隧道顶部周期照明。
 *  - support*：高架的桥墩（每隔若干格从桥面向下打桩到地面）。
 */
public class TrackProfile {

    public final String name;

    public int halfWidth = 1;   // 内部半宽（dx -halfWidth..halfWidth）
    public int height = 3;       // 内部净空高度（dy 0..height-1）

    public class_2680 floor = class_2246.field_10056.method_9564();

    public boolean enclosed = false;           // true=隧道（围墙+盖顶）
    public class_2680 wall = null;             // 墙 / 护栏材料（null=无）
    public class_2680 ceiling = null;          // 隧道顶
    public int railHeight = 2;                 // 开顶样式的护栏高度

    public class_2680 light = null;
    public int lightSpacing = 0;

    public boolean hasSupport = false;         // 是否打桥墩（中央）
    public int supportSpacing = 0;
    public class_2680 supportBlock = class_2246.field_10056.method_9564();
    public int supportMaxDepth = 48;

    public TrackProfile(String name) {
        this.name = name;
    }

    public TrackProfile size(int halfWidth, int height) {
        this.halfWidth = halfWidth;
        this.height = height;
        return this;
    }

    public TrackProfile floor(class_2680 floor) {
        this.floor = floor;
        return this;
    }

    /** 配置为封闭隧道：围墙 + 盖顶。 */
    public TrackProfile tunnel(class_2680 wall, class_2680 ceiling) {
        this.enclosed = true;
        this.wall = wall;
        this.ceiling = ceiling;
        return this;
    }

    /** 配置开顶护栏（高架/路基边缘）。 */
    public TrackProfile railing(class_2680 wall, int railHeight) {
        this.wall = wall;
        this.railHeight = railHeight;
        return this;
    }

    public TrackProfile lighting(class_2680 light, int spacing) {
        this.light = light;
        this.lightSpacing = spacing;
        return this;
    }

    /** 中央桥墩：每隔 spacing 格向下打桩到地面。 */
    public TrackProfile support(int spacing, class_2680 block, int maxDepth) {
        this.hasSupport = true;
        this.supportSpacing = spacing;
        this.supportBlock = block;
        this.supportMaxDepth = maxDepth;
        return this;
    }
}
