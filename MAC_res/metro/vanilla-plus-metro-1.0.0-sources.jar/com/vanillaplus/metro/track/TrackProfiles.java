package com.vanillaplus.metro.track;

import java.util.List;
import net.minecraft.class_2246;
import net.minecraft.class_2680;

/**
 * 内置的轨道横截面预设。之后可扩展为数据包 JSON / 游戏内设计台。
 */
public final class TrackProfiles {
    private TrackProfiles() {}

    private static final class_2680 BRICK = class_2246.field_10056.method_9564();
    private static final class_2680 SMOOTH = class_2246.field_10360.method_9564();
    private static final class_2680 WALL = class_2246.field_10252.method_9564();
    private static final class_2680 LAMP = class_2246.field_10174.method_9564();

    /** 地面路基：平整路基 + 上方净空，无墙。 */
    public static final TrackProfile GROUND = new TrackProfile("地面路基")
            .size(1, 3)
            .floor(SMOOTH);

    /** 标准隧道：3 宽内净空 + 石砖围墙盖顶 + 顶部照明。 */
    public static final TrackProfile TUNNEL = new TrackProfile("标准隧道")
            .size(1, 3)
            .floor(BRICK)
            .tunnel(BRICK, BRICK)
            .lighting(LAMP, 5);

    /** 高架桥：5 宽桥面 + 两侧石砖墙护栏 + 中央桥墩自动落地。 */
    public static final TrackProfile VIADUCT = new TrackProfile("高架桥")
            .size(2, 3)
            .floor(BRICK)
            .railing(WALL, 2)
            .support(4, BRICK, 48);

    public static final List<TrackProfile> ALL = List.of(GROUND, TUNNEL, VIADUCT);
}
