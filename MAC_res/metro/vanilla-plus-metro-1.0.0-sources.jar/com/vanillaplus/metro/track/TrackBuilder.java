package com.vanillaplus.metro.track;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2768;
import net.minecraft.class_3218;

/**
 * 轨道生成器：多点折线 → 中心线 → 沿中心线施工。
 *
 * 施工方式：直线段用"沿行进方向的薄片截面"逐格铺（不会在坡道上互相覆盖路基、两端不鼓出）；
 * 只有 90°转角节点用"正方形截面"把两段接通，保证拐角内腔连通、墙壳/护栏无缝。
 * 封闭样式(隧道)的墙由内腔边界抠出；开顶样式(高架/路基)的护栏沿每段两侧铺。
 *
 * 约束：折线各段轴对齐（法杖自动对齐）；每段可独立上下坡(≤1:1)，转角两侧各留 1 格缓冲保持水平。
 */
public final class TrackBuilder {
    private TrackBuilder() {}

    private static final int MAX_TOTAL_NODES = 1200;
    private static final class_2680 AIR = class_2246.field_10124.method_9564();
    private static final class_2350[] HORIZONTALS = {class_2350.field_11043, class_2350.field_11035, class_2350.field_11034, class_2350.field_11039};

    public record Result(boolean ok, String message, int length) {}

    public static Result build(class_3218 world, List<class_2338> waypoints, boolean slopeEnabled, TrackProfile profile) {
        if (waypoints == null || waypoints.size() < 2) {
            return new Result(false, "至少需要 2 个路点", 0);
        }
        int firstY = waypoints.get(0).method_10264();
        int lastIdx = waypoints.size() - 1;

        List<class_2338> center = new ArrayList<>();
        int prevY = slopeEnabled ? firstY : firstY; // 每段起点高度（上一段终点）
        for (int i = 0; i < lastIdx; i++) {
            class_2338 a = waypoints.get(i);
            class_2338 b = waypoints.get(i + 1);
            class_2350 dir = horizDir(a, b);
            if (dir == null) {
                return new Result(false, "路点 #" + (i + 2) + " 与上一个重合", 0);
            }
            int legLen = Math.max(Math.abs(b.method_10263() - a.method_10263()), Math.abs(b.method_10260() - a.method_10260()));
            int aY = prevY;
            int bY = slopeEnabled ? b.method_10264() : firstY;
            int rise = bY - aY;

            // 拐角轨不能上下坡，故每个拐角两侧各留 1 格“平缓落地”，坡度只在直线段内爬
            int startLanding = (i > 0) ? 1 : 0;          // 上一个拐点
            int endLanding = (i < lastIdx - 1) ? 1 : 0;  // 下一个拐点
            int rampSteps = legLen - startLanding - endLanding;
            if (rampSteps < Math.abs(rise)) {
                return new Result(false, "第 " + (i + 1) + " 段落差过陡（落差 " + rise
                        + " 需要更长的水平距离，转弯两侧各留 1 格缓冲）", 0);
            }

            int startJ = (i == 0) ? 0 : 1; // 跳过与上一段共用的路点
            for (int j = startJ; j <= legLen; j++) {
                int y;
                if (j <= startLanding) {
                    y = aY;
                } else if (j >= legLen - endLanding) {
                    y = bY;
                } else {
                    y = aY + Math.round((float) rise * (j - startLanding) / rampSteps);
                }
                center.add(new class_2338(a.method_10263() + dir.method_10148() * j, y, a.method_10260() + dir.method_10165() * j));
            }
            prevY = bY;
            if (center.size() > MAX_TOTAL_NODES) {
                return new Result(false, "线路过长（> " + MAX_TOTAL_NODES + " 格）", 0);
            }
        }
        if (center.size() < 2) {
            return new Result(false, "线路太短", 0);
        }

        int n = center.size();
        class_2350[] seg = new class_2350[n];
        boolean[] corner = new boolean[n];
        for (int k = 0; k < n; k++) {
            class_2350 din = k > 0 ? horizDir(center.get(k - 1), center.get(k)) : null;
            class_2350 dout = k < n - 1 ? horizDir(center.get(k), center.get(k + 1)) : null;
            corner[k] = din != null && dout != null && din != dout;
            seg[k] = dout != null ? dout : din;
        }

        stampAndShell(world, center, seg, corner, profile);
        placeRails(world, center);
        placeLights(world, center, profile);
        placePillars(world, center, profile);

        return new Result(true, "已生成 " + (n - 1) + " 格 [" + profile.name + "] 轨道", n - 1);
    }

    // ------------------------------------------------------------------
    // 施工主体
    // ------------------------------------------------------------------
    private static void stampAndShell(class_3218 world, List<class_2338> center, class_2350[] seg, boolean[] corner, TrackProfile p) {
        int hw = p.halfWidth;
        int H = p.height;
        int fw = hw + (p.enclosed ? 1 : 0); // 封闭样式的路基/顶要盖住墙脚，比内净空宽 1

        Set<class_2338> interior = new HashSet<>();
        Set<class_2338> floorSet = new HashSet<>();
        Set<class_2338> ceilingSet = new HashSet<>();

        for (int k = 0; k < center.size(); k++) {
            class_2338 c = center.get(k);
            for (int[] off : footprint(seg[k], corner[k], hw)) {
                class_2338 base = c.method_10069(off[0], 0, off[1]);
                for (int dy = 0; dy < H; dy++) {
                    interior.add(base.method_10086(dy));
                }
            }
            for (int[] off : footprint(seg[k], corner[k], fw)) {
                class_2338 base = c.method_10069(off[0], 0, off[1]);
                floorSet.add(base.method_10087(1));
                if (p.enclosed) {
                    ceilingSet.add(base.method_10086(H));
                }
            }
        }

        // 先清空气，再铺路基/盖顶（路基/顶优先，避免坡道上被相邻空气冲掉）
        for (class_2338 ip : interior) {
            world.method_8652(ip, AIR, class_2248.field_31036);
        }
        for (class_2338 fp : floorSet) {
            world.method_8652(fp, p.floor, class_2248.field_31036);
        }
        if (p.enclosed && p.ceiling != null) {
            for (class_2338 cp : ceilingSet) {
                world.method_8652(cp, p.ceiling, class_2248.field_31036);
            }
        }

        if (p.wall != null) {
            if (p.enclosed) {
                Set<class_2338> walls = new HashSet<>();
                for (class_2338 ip : interior) {
                    for (class_2350 d : HORIZONTALS) {
                        class_2338 nb = ip.method_10093(d);
                        if (!interior.contains(nb) && !floorSet.contains(nb) && !ceilingSet.contains(nb)) {
                            walls.add(nb);
                        }
                    }
                }
                for (class_2338 wp : walls) {
                    world.method_8652(wp, p.wall, class_2248.field_31036);
                }
                openTunnelEnds(world, center, p);
            } else {
                // 开顶护栏：沿桥面真实边界抠出（外侧/内侧、拐角都连续），只放过线路最两端的开口
                int last = center.size() - 1;
                Set<class_2338> firstFace = floorFootprint(center.get(0), seg[0], corner[0], fw);
                Set<class_2338> lastFace = floorFootprint(center.get(last), seg[last], corner[last], fw);
                class_2350 startOpen = seg[0].method_10153();
                class_2350 endOpen = seg[last];

                for (class_2338 fp : floorSet) {
                    boolean edge = false;
                    for (class_2350 d : HORIZONTALS) {
                        class_2338 nb = fp.method_10093(d);
                        // 认得台阶：邻格桥面在同高/高一格/低一格 都算连通，避免坡道上沿轨方向被误判为边缘而立栏挡道
                        if (floorSet.contains(nb) || floorSet.contains(nb.method_10084()) || floorSet.contains(nb.method_10074())) {
                            continue;
                        }
                        if (d == startOpen && firstFace.contains(fp)) {
                            continue; // 起点开口，不封横栏
                        }
                        if (d == endOpen && lastFace.contains(fp)) {
                            continue; // 终点开口，不封横栏
                        }
                        edge = true;
                        break;
                    }
                    if (edge) {
                        for (int dy = 0; dy < p.railHeight; dy++) {
                            world.method_8652(fp.method_10086(1 + dy), p.wall, class_2248.field_31036);
                        }
                    }
                }
            }
        }
    }

    /** 某个节点的路基（floor, dy=-1）方块集合，用于识别线路两端开口。 */
    private static Set<class_2338> floorFootprint(class_2338 node, class_2350 dir, boolean corner, int halfW) {
        Set<class_2338> s = new HashSet<>();
        for (int[] off : footprint(dir, corner, halfW)) {
            s.add(node.method_10069(off[0], 0, off[1]).method_10087(1));
        }
        return s;
    }

    /** 一个节点的横截面偏移：直线段=垂直行进方向的薄片；拐角=正方形（接通两段）。 */
    private static List<int[]> footprint(class_2350 dir, boolean corner, int halfW) {
        List<int[]> out = new ArrayList<>();
        if (corner || dir == null) {
            for (int dx = -halfW; dx <= halfW; dx++) {
                for (int dz = -halfW; dz <= halfW; dz++) {
                    out.add(new int[]{dx, dz});
                }
            }
        } else {
            class_2350 perp = dir.method_10170();
            for (int i = -halfW; i <= halfW; i++) {
                out.add(new int[]{perp.method_10148() * i, perp.method_10165() * i});
            }
        }
        return out;
    }

    /** 打通隧道两端封口，便于对接站台/延伸（仅清空气，不额外铺地）。 */
    private static void openTunnelEnds(class_3218 world, List<class_2338> center, TrackProfile p) {
        int last = center.size() - 1;
        openEnd(world, center.get(0), horizDir(center.get(1), center.get(0)), p);
        openEnd(world, center.get(last), horizDir(center.get(last - 1), center.get(last)), p);
    }

    private static void openEnd(class_3218 world, class_2338 node, class_2350 outward, TrackProfile p) {
        if (outward == null) {
            return;
        }
        class_2338 face = node.method_10093(outward);
        for (int dx = -p.halfWidth; dx <= p.halfWidth; dx++) {
            for (int dz = -p.halfWidth; dz <= p.halfWidth; dz++) {
                class_2338 base = face.method_10069(dx, 0, dz);
                for (int dy = 0; dy < p.height; dy++) {
                    world.method_8652(base.method_10086(dy), AIR, class_2248.field_31036);
                }
            }
        }
    }

    // ------------------------------------------------------------------
    // 轨道 / 照明 / 桥墩
    // ------------------------------------------------------------------
    private static void placeRails(class_3218 world, List<class_2338> center) {
        int last = center.size() - 1;
        for (int k = 0; k <= last; k++) {
            class_2338 cur = center.get(k);
            class_2350 dirIn = (k > 0) ? horizDir(center.get(k - 1), cur) : horizDir(cur, center.get(k + 1));
            class_2350 dirOut = (k < last) ? horizDir(cur, center.get(k + 1)) : dirIn;

            class_2768 shape;
            if (dirIn != null && dirOut != null && dirIn != dirOut) {
                shape = corner(dirIn.method_10153(), dirOut);
            } else {
                class_2350 dir = dirOut != null ? dirOut : dirIn;
                int dy = (k < last) ? center.get(k + 1).method_10264() - cur.method_10264() : 0;
                if (dy > 0) {
                    shape = ascending(dir);
                } else if (dy < 0) {
                    shape = ascending(dir.method_10153());
                } else {
                    shape = dir.method_10166() == class_2350.class_2351.field_11048 ? class_2768.field_12674 : class_2768.field_12665;
                }
            }
            world.method_8652(cur, class_2246.field_10167.method_9564().method_11657(class_2741.field_12507, shape), class_2248.field_31036);
        }
    }

    private static void placeLights(class_3218 world, List<class_2338> center, TrackProfile p) {
        if (p.light == null || p.lightSpacing <= 0) {
            return;
        }
        for (int k = 0; k < center.size(); k++) {
            if (k % p.lightSpacing == 0) {
                world.method_8652(center.get(k).method_10086(p.height), p.light, class_2248.field_31036);
            }
        }
    }

    private static void placePillars(class_3218 world, List<class_2338> center, TrackProfile p) {
        if (!p.hasSupport || p.supportSpacing <= 0) {
            return;
        }
        for (int k = 0; k < center.size(); k++) {
            if (k % p.supportSpacing == 0) {
                dropPillar(world, center.get(k), p);
            }
        }
    }

    private static void dropPillar(class_3218 world, class_2338 deckCenter, TrackProfile p) {
        class_2338.class_2339 m = deckCenter.method_10087(2).method_25503();
        int placed = 0;
        while (placed < p.supportMaxDepth && m.method_10264() > world.method_31607() && world.method_8320(m).method_45474()) {
            world.method_8652(m, p.supportBlock, class_2248.field_31036);
            m.method_10098(class_2350.field_11033);
            placed++;
        }
    }

    // ------------------------------------------------------------------
    // 几何辅助
    // ------------------------------------------------------------------
    public static class_2350 horizDir(class_2338 a, class_2338 b) {
        int dx = b.method_10263() - a.method_10263();
        int dz = b.method_10260() - a.method_10260();
        if (Math.abs(dx) >= Math.abs(dz)) {
            if (dx != 0) return dx > 0 ? class_2350.field_11034 : class_2350.field_11039;
            if (dz != 0) return dz > 0 ? class_2350.field_11035 : class_2350.field_11043;
            return null;
        }
        return dz > 0 ? class_2350.field_11035 : class_2350.field_11043;
    }

    private static class_2768 ascending(class_2350 dir) {
        return switch (dir) {
            case field_11034 -> class_2768.field_12667;
            case field_11039 -> class_2768.field_12666;
            case field_11043 -> class_2768.field_12670;
            default -> class_2768.field_12668;
        };
    }

    private static class_2768 corner(class_2350 a, class_2350 b) {
        boolean n = a == class_2350.field_11043 || b == class_2350.field_11043;
        boolean s = a == class_2350.field_11035 || b == class_2350.field_11035;
        boolean e = a == class_2350.field_11034 || b == class_2350.field_11034;
        boolean w = a == class_2350.field_11039 || b == class_2350.field_11039;
        if (n && e) return class_2768.field_12663;
        if (n && w) return class_2768.field_12672;
        if (s && e) return class_2768.field_12664;
        if (s && w) return class_2768.field_12671;
        return (e || w) ? class_2768.field_12674 : class_2768.field_12665;
    }
}
