package com.vanillaplus.metro.program;

import java.util.List;
import net.minecraft.class_2338;

/**
 * 可编程控制器的通用接口（站台核心块 / 可编程红石块等都实现它）。
 * 编辑器（指令平板）与绑定工具面向这个接口工作，从而不绑死具体方块类型。
 */
public interface ProgrammableController {

    String getProgram();

    /** 设置并编译程序；返回语法错误信息（null=成功）。 */
    String setProgram(String source);

    void setProgramMode(boolean mode);

    /** 把一个资源以某名字绑到本控制器。 */
    void addBinding(String name, String kind, class_2338 pos);

    /** 外部触发：运行本控制器里匹配该事件名的处理块（供跨控制器 call 用）。 */
    void runEvent(String event);

    /** 本控制器可用的候选词（事件 + 函数 + 资源类型 + 绑定名），供编辑器自动补全。 */
    List<String> apiCatalog();

    /** 已绑定资源清单：每行 "类型:名字"，供编辑器展示 + 名字补全。 */
    String bindingsInfo();
}
