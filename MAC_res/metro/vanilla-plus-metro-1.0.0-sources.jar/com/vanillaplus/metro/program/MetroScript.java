package com.vanillaplus.metro.program;

import java.util.ArrayList;
import java.util.List;

/**
 * Vanilla+ Metro 的事件-条件-动作小型 DSL 引擎（不依赖 Minecraft）。
 *
 * 语法概览：
 * <pre>
 *   on arrive {
 *     if has(0, -1, 0, redstone_block) and not door["北门"].open {
 *       door["北门"].open
 *       signal["S1"] = green
 *     } else {
 *       door["北门"].close
 *     }
 *     log("到站处理完毕")
 *   }
 *   on tick(10) { ... }
 * </pre>
 * 无任意循环 → 单次事件执行有界。命名资源（door["名"]）与全局函数（has/input/time/log…）都转发给 {@link ProgramContext}。
 */
public final class MetroScript {

    private final List<Handler> handlers;

    private MetroScript(List<Handler> handlers) {
        this.handlers = handlers;
    }

    /** 解析脚本；语法错误抛 {@link ScriptException}。 */
    public static MetroScript parse(String source) throws ScriptException {
        List<Token> tokens = new Lexer(source).lex();
        return new MetroScript(new Parser(tokens).parseProgram());
    }

    /** 运行所有匹配该事件名的处理块，返回执行了几个。 */
    public int run(String event, ProgramContext ctx) throws ScriptException {
        Interpreter interp = new Interpreter(ctx);
        int ran = 0;
        for (Handler h : handlers) {
            if (h.event.equals(event)) {
                interp.execBlock(h.body);
                ran++;
            }
        }
        return ran;
    }

    /** 该脚本定义了哪些事件（供编辑器/触发端参考）。 */
    public List<String> eventNames() {
        List<String> out = new ArrayList<>();
        for (Handler h : handlers) {
            if (!out.contains(h.event)) {
                out.add(h.event);
            }
        }
        return out;
    }

    /** on tick(N) 的节流参数，找不到返回 0。 */
    public int tickInterval() {
        for (Handler h : handlers) {
            if (h.event.equals("tick") && h.param != null) {
                return h.param;
            }
        }
        return 0;
    }

    // ==================================================================
    //  AST
    // ==================================================================
    private static final class Handler {
        final String event;
        final Integer param;
        final List<Stmt> body;
        Handler(String event, Integer param, List<Stmt> body) { this.event = event; this.param = param; this.body = body; }
    }

    private abstract static class Stmt { int line; }
    private static final class IfStmt extends Stmt { Expr cond; List<Stmt> thenBody; List<Stmt> elseBody; }
    private static final class ActionStmt extends Stmt { String kind, name, method; }
    private static final class AssignStmt extends Stmt { String kind, name; Expr value; }
    private static final class CallStmt extends Stmt { String func; List<Expr> args; }

    private abstract static class Expr { int line; }
    private static final class Lit extends Expr { Object value; }                 // Boolean / Long / String
    private static final class QueryExpr extends Expr { String kind, name, prop; }// door["A"].open (读)
    private static final class FuncExpr extends Expr { String func; List<Expr> args; }
    private static final class BinExpr extends Expr { String op; Expr l, r; }
    private static final class UnaryExpr extends Expr { String op; Expr e; }

    // ==================================================================
    //  词法
    // ==================================================================
    private enum T { IDENT, NUM, STR, SYM, EOF }
    private static final class Token {
        final T type; final String text; final int line;
        Token(T type, String text, int line) { this.type = type; this.text = text; this.line = line; }
    }

    private static final class Lexer {
        private final String s;
        private int i = 0, line = 1;
        Lexer(String s) { this.s = s; }

        List<Token> lex() throws ScriptException {
            List<Token> out = new ArrayList<>();
            while (i < s.length()) {
                char c = s.charAt(i);
                if (c == '\n') { line++; i++; continue; }
                if (Character.isWhitespace(c)) { i++; continue; }
                if (c == '#' || (c == '/' && peek(1) == '/')) { // 注释到行尾
                    while (i < s.length() && s.charAt(i) != '\n') i++;
                    continue;
                }
                if (c == '"') { out.add(string()); continue; }
                if (Character.isDigit(c)) { out.add(number()); continue; }
                if (Character.isLetter(c) || c == '_') { out.add(ident()); continue; }
                out.add(symbol());
            }
            out.add(new Token(T.EOF, "", line));
            return out;
        }

        private char peek(int k) { return i + k < s.length() ? s.charAt(i + k) : '\0'; }

        private Token string() throws ScriptException {
            int ln = line; i++; // 跳过开引号
            StringBuilder b = new StringBuilder();
            while (i < s.length() && s.charAt(i) != '"') {
                if (s.charAt(i) == '\n') line++;
                b.append(s.charAt(i++));
            }
            if (i >= s.length()) throw new ScriptException(ln, "字符串缺少结束引号");
            i++; // 跳过闭引号
            return new Token(T.STR, b.toString(), ln);
        }

        private Token number() {
            int ln = line; int start = i;
            while (i < s.length() && Character.isDigit(s.charAt(i))) i++;
            return new Token(T.NUM, s.substring(start, i), ln);
        }

        private Token ident() {
            int ln = line; int start = i;
            while (i < s.length() && (Character.isLetterOrDigit(s.charAt(i)) || s.charAt(i) == '_')) i++;
            return new Token(T.IDENT, s.substring(start, i), ln);
        }

        private Token symbol() throws ScriptException {
            int ln = line; char c = s.charAt(i);
            // 双字符符号
            String two = "" + c + peek(1);
            if (two.equals("==") || two.equals("!=") || two.equals("<=") || two.equals(">=")) {
                i += 2; return new Token(T.SYM, two, ln);
            }
            if ("{}[]().,=<>+-*/".indexOf(c) >= 0) {
                i++; return new Token(T.SYM, "" + c, ln);
            }
            throw new ScriptException(ln, "无法识别的字符 '" + c + "'");
        }
    }

    // ==================================================================
    //  语法（递归下降）
    // ==================================================================
    private static final class Parser {
        private final List<Token> t;
        private int p = 0;
        Parser(List<Token> t) { this.t = t; }

        private Token peek() { return t.get(p); }
        private Token next() { return t.get(p++); }
        private boolean isSym(String s) { Token x = peek(); return x.type == T.SYM && x.text.equals(s); }
        private boolean isKw(String s) { Token x = peek(); return x.type == T.IDENT && x.text.equals(s); }
        private boolean eof() { return peek().type == T.EOF; }

        private Token expectSym(String s) throws ScriptException {
            if (!isSym(s)) throw new ScriptException(peek().line, "期望 '" + s + "'，却是 '" + peek().text + "'");
            return next();
        }

        List<Handler> parseProgram() throws ScriptException {
            List<Handler> hs = new ArrayList<>();
            while (!eof()) {
                if (!isKw("on")) throw new ScriptException(peek().line, "顶层只能是 'on 事件 { ... }'，却是 '" + peek().text + "'");
                hs.add(parseHandler());
            }
            return hs;
        }

        private Handler parseHandler() throws ScriptException {
            next(); // on
            if (peek().type != T.IDENT) throw new ScriptException(peek().line, "on 后面要跟事件名");
            String event = next().text;
            Integer param = null;
            if (isSym("(")) {
                next();
                if (peek().type == T.NUM) { param = Integer.parseInt(next().text); }
                expectSym(")");
            }
            List<Stmt> body = parseBlock();
            return new Handler(event, param, body);
        }

        private List<Stmt> parseBlock() throws ScriptException {
            expectSym("{");
            List<Stmt> stmts = new ArrayList<>();
            while (!isSym("}") && !eof()) stmts.add(parseStmt());
            expectSym("}");
            return stmts;
        }

        private Stmt parseStmt() throws ScriptException {
            if (isKw("if")) return parseIf();
            Token x = peek();
            if (x.type == T.IDENT) {
                // 资源语句（IDENT '[' ...）还是函数调用（IDENT '('）
                if (t.get(p + 1).type == T.SYM && t.get(p + 1).text.equals("[")) return parseResourceStmt();
                if (t.get(p + 1).type == T.SYM && t.get(p + 1).text.equals("(")) return parseCallStmt();
            }
            throw new ScriptException(x.line, "无法解析的语句，从 '" + x.text + "' 开始");
        }

        private Stmt parseIf() throws ScriptException {
            int ln = next().line; // if
            Expr cond = parseExpr();
            List<Stmt> thenB = parseBlock();
            List<Stmt> elseB = null;
            if (isKw("else")) {
                next();
                if (isKw("if")) { IfStmt inner = (IfStmt) parseIf(); elseB = new ArrayList<>(); elseB.add(inner); }
                else elseB = parseBlock();
            }
            IfStmt s = new IfStmt(); s.line = ln; s.cond = cond; s.thenBody = thenB; s.elseBody = elseB;
            return s;
        }

        private Stmt parseResourceStmt() throws ScriptException {
            int ln = peek().line;
            String kind = next().text;                 // IDENT
            expectSym("[");
            if (peek().type != T.STR) throw new ScriptException(peek().line, "资源名要用引号：" + kind + "[\"名字\"]");
            String name = next().text;
            expectSym("]");
            if (isSym(".")) {
                next(); if (peek().type != T.IDENT) throw new ScriptException(peek().line, "'.' 后面要跟动作名");
                ActionStmt a = new ActionStmt(); a.line = ln; a.kind = kind; a.name = name; a.method = next().text; return a;
            }
            if (isSym("=")) {
                next(); AssignStmt a = new AssignStmt(); a.line = ln; a.kind = kind; a.name = name; a.value = parseExpr(); return a;
            }
            throw new ScriptException(ln, kind + "[\"" + name + "\"] 后面要跟 '.动作' 或 '= 值'");
        }

        private Stmt parseCallStmt() throws ScriptException {
            int ln = peek().line;
            String func = next().text;
            CallStmt c = new CallStmt(); c.line = ln; c.func = func; c.args = parseArgs(); return c;
        }

        private List<Expr> parseArgs() throws ScriptException {
            expectSym("(");
            List<Expr> args = new ArrayList<>();
            if (!isSym(")")) {
                args.add(parseExpr());
                while (isSym(",")) { next(); args.add(parseExpr()); }
            }
            expectSym(")");
            return args;
        }

        // 表达式（优先级：or < and < 比较 < 加减 < 一元 < 原子）
        private Expr parseExpr() throws ScriptException { return parseOr(); }

        private Expr parseOr() throws ScriptException {
            Expr l = parseAnd();
            while (isKw("or")) { int ln = next().line; Expr r = parseAnd(); l = bin("or", l, r, ln); }
            return l;
        }
        private Expr parseAnd() throws ScriptException {
            Expr l = parseCmp();
            while (isKw("and")) { int ln = next().line; Expr r = parseCmp(); l = bin("and", l, r, ln); }
            return l;
        }
        private Expr parseCmp() throws ScriptException {
            Expr l = parseAdd();
            if (isSym("==") || isSym("!=") || isSym("<") || isSym(">") || isSym("<=") || isSym(">=")) {
                Token op = next(); Expr r = parseAdd(); return bin(op.text, l, r, op.line);
            }
            return l;
        }
        private Expr parseAdd() throws ScriptException {
            Expr l = parseUnary();
            while (isSym("+") || isSym("-")) { Token op = next(); Expr r = parseUnary(); l = bin(op.text, l, r, op.line); }
            return l;
        }
        private Expr parseUnary() throws ScriptException {
            if (isKw("not")) { int ln = next().line; UnaryExpr u = new UnaryExpr(); u.line = ln; u.op = "not"; u.e = parseUnary(); return u; }
            if (isSym("-")) { int ln = next().line; UnaryExpr u = new UnaryExpr(); u.line = ln; u.op = "-"; u.e = parseUnary(); return u; }
            return parseAtom();
        }

        private Expr parseAtom() throws ScriptException {
            Token x = peek();
            if (x.type == T.NUM) { next(); Lit l = new Lit(); l.line = x.line; l.value = Long.parseLong(x.text); return l; }
            if (x.type == T.STR) { next(); Lit l = new Lit(); l.line = x.line; l.value = x.text; return l; }
            if (isSym("(")) { next(); Expr e = parseExpr(); expectSym(")"); return e; }
            if (x.type == T.IDENT) {
                if (x.text.equals("true") || x.text.equals("false")) { next(); Lit l = new Lit(); l.line = x.line; l.value = x.text.equals("true"); return l; }
                // 资源查询 IDENT '[' STR ']' '.' IDENT
                if (t.get(p + 1).type == T.SYM && t.get(p + 1).text.equals("[")) {
                    String kind = next().text; expectSym("[");
                    if (peek().type != T.STR) throw new ScriptException(peek().line, "资源名要用引号");
                    String name = next().text; expectSym("]"); expectSym(".");
                    if (peek().type != T.IDENT) throw new ScriptException(peek().line, "资源查询要写 '.属性'");
                    QueryExpr q = new QueryExpr(); q.line = x.line; q.kind = kind; q.name = name; q.prop = next().text; return q;
                }
                // 函数调用 IDENT '(' ... ')'
                if (t.get(p + 1).type == T.SYM && t.get(p + 1).text.equals("(")) {
                    String func = next().text; FuncExpr f = new FuncExpr(); f.line = x.line; f.func = func; f.args = parseArgs(); return f;
                }
                // 裸标识符 → 当作字符串字面量（如 red / redstone_block / north）
                next(); Lit l = new Lit(); l.line = x.line; l.value = x.text; return l;
            }
            throw new ScriptException(x.line, "无法解析的表达式，从 '" + x.text + "' 开始");
        }

        private Expr bin(String op, Expr l, Expr r, int line) { BinExpr b = new BinExpr(); b.line = line; b.op = op; b.l = l; b.r = r; return b; }
    }

    // ==================================================================
    //  解释器
    // ==================================================================
    private static final class Interpreter {
        private final ProgramContext ctx;
        private int steps = 0;
        private static final int MAX_STEPS = 10000;
        Interpreter(ProgramContext ctx) { this.ctx = ctx; }

        void execBlock(List<Stmt> body) throws ScriptException {
            for (Stmt s : body) exec(s);
        }

        private void exec(Stmt s) throws ScriptException {
            if (++steps > MAX_STEPS) throw new ScriptException(s.line, "执行步数超上限（可能程序过于复杂）");
            if (s instanceof IfStmt f) {
                if (asBool(eval(f.cond), f.line)) execBlock(f.thenBody);
                else if (f.elseBody != null) execBlock(f.elseBody);
            } else if (s instanceof ActionStmt a) {
                ctx.action(a.kind, a.name, a.method);
            } else if (s instanceof AssignStmt a) {
                ctx.assign(a.kind, a.name, eval(a.value));
            } else if (s instanceof CallStmt c) {
                Object[] args = new Object[c.args.size()];
                for (int k = 0; k < args.length; k++) args[k] = eval(c.args.get(k));
                ctx.function(c.func, args);
            }
        }

        private Object eval(Expr e) throws ScriptException {
            if (++steps > MAX_STEPS) throw new ScriptException(e.line, "执行步数超上限");
            if (e instanceof Lit l) return l.value;
            if (e instanceof QueryExpr q) return ctx.query(q.kind, q.name, q.prop);
            if (e instanceof FuncExpr f) {
                Object[] args = new Object[f.args.size()];
                for (int k = 0; k < args.length; k++) args[k] = eval(f.args.get(k));
                return ctx.function(f.func, args);
            }
            if (e instanceof UnaryExpr u) {
                Object v = eval(u.e);
                if (u.op.equals("not")) return !asBool(v, u.line);
                return -asLong(v, u.line);
            }
            if (e instanceof BinExpr b) return evalBin(b);
            throw new ScriptException(e.line, "未知表达式");
        }

        private Object evalBin(BinExpr b) throws ScriptException {
            switch (b.op) {
                case "and": return asBool(eval(b.l), b.line) && asBool(eval(b.r), b.line);
                case "or":  return asBool(eval(b.l), b.line) || asBool(eval(b.r), b.line);
            }
            Object l = eval(b.l), r = eval(b.r);
            switch (b.op) {
                case "==": return equalsValue(l, r);
                case "!=": return !equalsValue(l, r);
                case "+":  return asLong(l, b.line) + asLong(r, b.line);
                case "-":  return asLong(l, b.line) - asLong(r, b.line);
                case "<":  return asLong(l, b.line) < asLong(r, b.line);
                case ">":  return asLong(l, b.line) > asLong(r, b.line);
                case "<=": return asLong(l, b.line) <= asLong(r, b.line);
                case ">=": return asLong(l, b.line) >= asLong(r, b.line);
                default: throw new ScriptException(b.line, "未知运算符 " + b.op);
            }
        }

        private boolean equalsValue(Object a, Object b) {
            if (a instanceof Number && b instanceof Number) return asLongUnsafe(a) == asLongUnsafe(b);
            return String.valueOf(a).equals(String.valueOf(b));
        }

        private boolean asBool(Object v, int line) throws ScriptException {
            if (v instanceof Boolean b) return b;
            if (v instanceof Number n) return n.longValue() != 0;
            throw new ScriptException(line, "期望布尔值，得到 " + v);
        }
        private long asLong(Object v, int line) throws ScriptException {
            if (v instanceof Number n) return n.longValue();
            if (v instanceof Boolean b) return b ? 1 : 0;
            throw new ScriptException(line, "期望数字，得到 " + v);
        }
        private long asLongUnsafe(Object v) { return ((Number) v).longValue(); }
    }
}
