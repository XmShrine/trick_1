package com.vanillaplus.metro.program;

import com.vanillaplus.metro.block.entity.MetroSignalBlockEntity;
import net.minecraft.class_2241;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2768;
import net.minecraft.class_3218;

/**
 * 通用执行器：把"设信号灯 / 扳道岔"等对某坐标资源的写操作集中于此，供各控制器的脚本上下文复用。
 */
public final class Actuators {
    private Actuators() {}

    /** 设信号灯为红/绿（会切到手动模式，停止自动占用检测）。 */
    public static void setSignal(class_3218 world, class_2338 pos, String color) throws ScriptException {
        if (!(world.method_8321(pos) instanceof MetroSignalBlockEntity be)) {
            throw new ScriptException(0, "该坐标不是信号灯");
        }
        boolean green = color.equalsIgnoreCase("green");
        if (!green && !color.equalsIgnoreCase("red")) {
            throw new ScriptException(0, "信号只能设 red 或 green");
        }
        be.setManual(green);
    }

    /** 把一段普通铁轨设为指定形状（north_south / east_west / north_east / ... 见 RailShape）。 */
    public static void setSwitch(class_3218 world, class_2338 pos, String shapeName) throws ScriptException {
        class_2680 s = world.method_8320(pos);
        if (!(s.method_26204() instanceof class_2241) || !s.method_28498(class_2741.field_12507)) {
            throw new ScriptException(0, "该坐标不是可变形状的普通铁轨");
        }
        class_2768 shape;
        try {
            shape = class_2768.valueOf(shapeName.toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new ScriptException(0, "未知轨道形状 \"" + shapeName + "\"");
        }
        world.method_8652(pos, s.method_11657(class_2741.field_12507, shape), class_2248.field_31036);
    }
}
