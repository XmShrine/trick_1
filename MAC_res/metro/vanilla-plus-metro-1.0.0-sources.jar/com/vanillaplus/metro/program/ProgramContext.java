package com.vanillaplus.metro.program;

/**
 * DSL 引擎与游戏世界之间的对接接口（引擎本身不依赖 Minecraft，便于独立测试）。
 *
 * 解释器把脚本里的一切"读世界/写世界"都通过这四个方法转发出去；具体实现（游戏内）由控制器方块提供，
 * 测试时用一个假的实现即可。命名资源（door["北门"]）的解析、绑定表查询都在实现里做。
 */
public interface ProgramContext {

    /** 资源动作：door["北门"].open → action("door","北门","open") */
    void action(String kind, String name, String method) throws ScriptException;

    /** 资源赋值：signal["S1"] = red → assign("signal","S1","red") */
    void assign(String kind, String name, Object value) throws ScriptException;

    /** 资源查询（读值）：door["北门"].open → query("door","北门","open") 返回 Boolean/Long/String */
    Object query(String kind, String name, String prop) throws ScriptException;

    /** 全局函数：has(0,-1,0,redstone_block) / input() / time() / occupied() / log(..) / call(..) / run(..) */
    Object function(String name, Object[] args) throws ScriptException;
}
