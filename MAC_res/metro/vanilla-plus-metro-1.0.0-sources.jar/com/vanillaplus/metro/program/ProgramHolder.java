package com.vanillaplus.metro.program;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import net.minecraft.class_2338;
import net.minecraft.class_2487;

/**
 * 可复用的"程序 + 模式开关 + 命名绑定表 + 编译/运行"机器。
 * 各可编程方块实体持有一个，把编程相关的逻辑集中于此（避免每个方块重复实现）。
 */
public final class ProgramHolder {

    public record Binding(String kind, class_2338 pos) {}

    private String program = "";
    private boolean mode = false;
    private transient MetroScript compiled = null;
    private transient String error = null;
    private final Map<String, Binding> bindings = new HashMap<>();

    public String getProgram() { return program; }
    public boolean isMode() { return mode; }
    public void setMode(boolean m) { this.mode = m; }

    /** 设置并编译；返回语法错误（null=成功）。 */
    public String setProgram(String src) {
        this.program = src == null ? "" : src;
        compile();
        return error;
    }

    private void compile() {
        error = null;
        compiled = null;
        if (program == null || program.isBlank()) {
            return;
        }
        try {
            compiled = MetroScript.parse(program);
        } catch (ScriptException e) {
            error = e.getMessage();
        }
    }

    public boolean hasProgram() { return compiled != null; }
    public int tickInterval() { return compiled != null ? compiled.tickInterval() : 0; }

    /** 运行匹配事件；返回运行时错误信息（null=成功或无程序）。 */
    public String run(String event, ProgramContext ctx) {
        if (compiled == null) {
            return null;
        }
        try {
            compiled.run(event, ctx);
            return null;
        } catch (ScriptException e) {
            return e.getMessage();
        }
    }

    public void addBinding(String name, String kind, class_2338 pos) { bindings.put(name, new Binding(kind, pos.method_10062())); }
    public Binding binding(String name) { return bindings.get(name); }
    public Set<String> bindingNames() { return bindings.keySet(); }

    /** 每行 "类型:名字"。 */
    public String bindingsInfo() {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, Binding> e : bindings.entrySet()) {
            if (sb.length() > 0) sb.append('\n');
            sb.append(e.getValue().kind()).append(':').append(e.getKey());
        }
        return sb.toString();
    }

    public void writeNbt(class_2487 nbt) {
        nbt.method_10582("Program", program);
        nbt.method_10556("ProgramMode", mode);
        class_2487 bn = new class_2487();
        for (Map.Entry<String, Binding> e : bindings.entrySet()) {
            class_2487 one = new class_2487();
            one.method_10582("Kind", e.getValue().kind());
            one.method_10544("Pos", e.getValue().pos().method_10063());
            bn.method_10566(e.getKey(), one);
        }
        nbt.method_10566("Bindings", bn);
    }

    public void readNbt(class_2487 nbt) {
        program = nbt.method_10558("Program");
        mode = nbt.method_10577("ProgramMode");
        bindings.clear();
        class_2487 bn = nbt.method_10562("Bindings");
        for (String key : bn.method_10541()) {
            class_2487 one = bn.method_10562(key);
            bindings.put(key, new Binding(one.method_10558("Kind"), class_2338.method_10092(one.method_10537("Pos"))));
        }
        compile();
    }
}
