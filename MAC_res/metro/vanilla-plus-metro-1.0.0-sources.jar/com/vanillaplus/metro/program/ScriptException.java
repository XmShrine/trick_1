package com.vanillaplus.metro.program;

/** DSL 解析/执行错误，带行号，便于在编辑器里逐行报错。 */
public class ScriptException extends Exception {
    public final int line;

    public ScriptException(int line, String message) {
        super((line > 0 ? "第 " + line + " 行：" : "") + message);
        this.line = line;
    }
}
