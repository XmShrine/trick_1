package com.vanillaplus.metro.program;

/**
 * 跨控制器 call 的深度护栏：同步触发但限制递归深度，防止 A→B→A 无限调用/爆栈。
 */
public final class CallGuard {
    private CallGuard() {}

    private static int depth = 0;
    private static final int MAX_DEPTH = 8;

    public static void fire(ProgrammableController target, String event) {
        if (depth >= MAX_DEPTH) {
            return; // 超过深度：忽略，防死循环
        }
        depth++;
        try {
            target.runEvent(event);
        } finally {
            depth--;
        }
    }
}
