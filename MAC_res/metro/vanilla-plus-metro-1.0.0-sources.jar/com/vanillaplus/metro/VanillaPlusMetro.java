package com.vanillaplus.metro;

import com.vanillaplus.metro.coupling.CouplingHandler;
import com.vanillaplus.metro.metro.SignalBinding;
import com.vanillaplus.metro.metro.TrainChunkLoader;
import com.vanillaplus.metro.registry.ModAttachments;
import com.vanillaplus.metro.registry.ModBlockEntities;
import com.vanillaplus.metro.registry.ModBlocks;
import com.vanillaplus.metro.registry.ModItems;
import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 原版拓展·轻量化地铁系统 (Vanilla+ Metro) 主入口。
 *
 * 核心理念：原版轨道，硬核优化，智能控制，现代视觉。
 */
public class VanillaPlusMetro implements ModInitializer {

    public static final String MOD_ID = "vanilla_metro";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("正在初始化 {} ...", "Vanilla+ Metro");

        // 特性一：连挂棒 + 列车组物理同步
        ModAttachments.register();   // 附着数据类型（记录“跟随的前车”）
        ModItems.register();         // 连挂棒 (Coupler) 物品
        CouplingHandler.register();  // 右键连挂 / 潜行解挂 的交互逻辑

        // 特性二/三：站台方块系统 + 停靠/发车控制 + 突破限速（逻辑在方块实体与 Mixin 内）
        ModBlocks.register();
        ModBlockEntities.register();

        // 特性四：线路总控面板 BFS 沿轨拓扑检测（逻辑在方块实体内，右键触发）

        // 增补·信号系统：信号配置器绑定信号灯到线路（红绿灯逻辑在信号方块实体内）
        SignalBinding.register();

        // 施工法杖：左键清空路点手势
        com.vanillaplus.metro.item.ConstructionWandItem.registerClearGesture();

        // 指令控制台：网络包 + 服务端执行（界面在客户端入口）
        com.vanillaplus.metro.command.CommandConsole.register();

        // 绑定工具：把资源以名字绑到控制器（供程序 door["名"] 引用）
        com.vanillaplus.metro.metro.BindingHandler.register();

        // 特性五：列车自带区块加载（防卡死急停在矿车 Mixin 内驱动）
        TrainChunkLoader.register();

        LOGGER.info("{} 初始化完成！地铁系统（连挂/站台/线路/安全）已就绪。", "Vanilla+ Metro");
    }
}
