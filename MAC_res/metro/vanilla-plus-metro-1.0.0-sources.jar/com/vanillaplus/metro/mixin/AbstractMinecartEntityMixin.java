package com.vanillaplus.metro.mixin;

import com.vanillaplus.metro.coupling.CouplingHandler;
import com.vanillaplus.metro.metro.CruiseController;
import com.vanillaplus.metro.metro.TrainSafety;
import com.vanillaplus.metro.registry.ModAttachments;
import net.fabricmc.fabric.api.attachment.v1.AttachmentTarget;
import net.minecraft.class_1688;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 矿车物理优化入口。
 *
 *  - tick 末尾驱动“连挂跟随”逻辑（列车组物理同步）。
 *  - getMaxSpeed 拦截：当矿车带有巡航速度附着（由站台核心块发车时赋予）时，
 *    突破原版 0.4/tick(8m/s) 的限速，允许更高巡航速度（如 16 / 24 m/s）。
 */
@Mixin(class_1688.class)
public abstract class AbstractMinecartEntityMixin {

    @Inject(method = "tick", at = @At("TAIL"))
    private void vanillaMetro$onTick(CallbackInfo ci) {
        class_1688 self = (class_1688) (Object) this;
        CouplingHandler.tickFollower(self);   // 连挂跟随（列车组同步）
        CruiseController.maintain(self);      // 巡航自驱：维持站台设定的巡航速度
        TrainSafety.checkCollision(self);     // 防卡死：迎面/追尾逼近时紧急制动
    }

    @Inject(method = "getMaxSpeed", at = @At("HEAD"), cancellable = true)
    private void vanillaMetro$raiseMaxSpeed(CallbackInfoReturnable<Double> cir) {
        Double cruise = ((AttachmentTarget) this).getAttached(ModAttachments.CRUISE_SPEED);
        if (cruise != null && cruise > 0.0D) {
            cir.setReturnValue(cruise);
        }
    }
}
