package com.vanillaplus.metro.registry;

import com.mojang.serialization.Codec;
import com.vanillaplus.metro.VanillaPlusMetro;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.minecraft.class_2960;
import net.minecraft.class_4844;
import java.util.UUID;

/**
 * 实体附着数据（Fabric Data Attachment API）。
 *
 * 用附着数据而非手写 NBT，好处是 {@code persistent(...)} 会自动随实体存档/读档，
 * 无需在 Mixin 里去猜 {@code writeCustomDataToNbt} 之类的方法名。
 */
public final class ModAttachments {
    private ModAttachments() {}

    /**
     * FOLLOW_TARGET：记录“这节车厢跟随的前车 UUID”。
     * 一节车厢若带有该附着数据 = 它是某辆前车的跟随者（列车组的后续车厢）。
     */
    public static AttachmentType<UUID> FOLLOW_TARGET;

    /**
     * CRUISE_SPEED：赋予该矿车的巡航速度上限（格/tick）。
     * 由站台核心块发车时设置，突破原版 0.4/tick(8m/s) 的限制；连挂时会同步给后续车厢。
     */
    public static AttachmentType<Double> CRUISE_SPEED;

    /**
     * CRUISE_SUPPRESS_UNTIL：抑制“巡航自驱”到某个游戏刻为止（瞬态，不存档）。
     * 站台进站/停靠、信号红灯制动等控制器每 tick 刷新它，控制结束后很快过期、自驱自动恢复，
     * 从而避免自驱与减速/制动逻辑互相打架。
     */
    public static AttachmentType<Long> CRUISE_SUPPRESS_UNTIL;

    public static void register() {
        FOLLOW_TARGET = AttachmentRegistry.createPersistent(
                class_2960.method_60655(VanillaPlusMetro.MOD_ID, "follow_target"),
                class_4844.field_40825
        );
        CRUISE_SPEED = AttachmentRegistry.createPersistent(
                class_2960.method_60655(VanillaPlusMetro.MOD_ID, "cruise_speed"),
                Codec.DOUBLE
        );
        CRUISE_SUPPRESS_UNTIL = AttachmentRegistry.<Long>create(
                class_2960.method_60655(VanillaPlusMetro.MOD_ID, "cruise_suppress_until")
        );
    }
}
