package com.vanillaplus.metro.registry;

import com.vanillaplus.metro.VanillaPlusMetro;
import com.vanillaplus.metro.item.ConstructionWandItem;
import com.vanillaplus.metro.item.CouplerItem;
import com.vanillaplus.metro.item.SignalConfiguratorItem;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7706;
import net.minecraft.class_7923;

public final class ModItems {
    private ModItems() {}

    /**
     * 连挂棒。maxCount(1)：作为工具，一组一件。
     * 注意：本项目基于 Minecraft 1.21.0，Item.Settings 无需 registryKey；
     * 若升级到 1.21.2+，需改为 {@code new Item.Settings().registryKey(...)}。
     */
    public static final class_1792 COUPLER = new CouplerItem(new class_1792.class_1793().method_7889(1));

    /** 信号配置器：把信号灯注册到线路总控面板。 */
    public static final class_1792 SIGNAL_CONFIGURATOR = new SignalConfiguratorItem(new class_1792.class_1793().method_7889(1));

    /** 施工法杖：沿直线自动生成轨道基建（地面/隧道/高架）。 */
    public static final class_1792 CONSTRUCTION_WAND = new ConstructionWandItem(new class_1792.class_1793().method_7889(1));

    /** 指令平板：右键打开多行指令控制台。 */
    public static final class_1792 COMMAND_TABLET = new class_1792(new class_1792.class_1793().method_7889(1));

    /** 蓝色红石粉：铺在地上就是不衰减的蓝红石线。 */
    public static final class_1792 BLUE_REDSTONE = new net.minecraft.class_1747(ModBlocks.BLUE_REDSTONE_WIRE, new class_1792.class_1793());

    /** 绑定工具：铁砧改名后，右键资源→右键控制器，把资源以该名字绑定。 */
    public static final class_1792 BINDING_TOOL = new class_1792(new class_1792.class_1793().method_7889(1));

    public static void register() {
        class_2378.method_10230(class_7923.field_41178, id("coupler"), COUPLER);
        class_2378.method_10230(class_7923.field_41178, id("signal_configurator"), SIGNAL_CONFIGURATOR);
        class_2378.method_10230(class_7923.field_41178, id("construction_wand"), CONSTRUCTION_WAND);
        class_2378.method_10230(class_7923.field_41178, id("command_tablet"), COMMAND_TABLET);
        class_2378.method_10230(class_7923.field_41178, id("blue_redstone"), BLUE_REDSTONE);
        class_2378.method_10230(class_7923.field_41178, id("binding_tool"), BINDING_TOOL);

        // 放进创造模式「工具与实用物品」标签页，方便取用
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41060)
                .register(entries -> {
                    entries.method_45421(COUPLER);
                    entries.method_45421(SIGNAL_CONFIGURATOR);
                    entries.method_45421(CONSTRUCTION_WAND);
                    entries.method_45421(COMMAND_TABLET);
                    entries.method_45421(BINDING_TOOL);
                });
        // 蓝红石放进「红石」页
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40198)
                .register(entries -> entries.method_45421(BLUE_REDSTONE));
    }

    private static class_2960 id(String path) {
        return class_2960.method_60655(VanillaPlusMetro.MOD_ID, path);
    }
}
