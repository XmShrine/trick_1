package com.vanillaplus.metro.registry;

import com.vanillaplus.metro.VanillaPlusMetro;
import com.vanillaplus.metro.block.entity.LineControlPanelBlockEntity;
import com.vanillaplus.metro.block.entity.MetroSignalBlockEntity;
import com.vanillaplus.metro.block.entity.PlatformCoreBlockEntity;
import com.vanillaplus.metro.block.entity.RedstoneLogicBlockEntity;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.class_2378;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public final class ModBlockEntities {
    private ModBlockEntities() {}

    public static final class_2591<PlatformCoreBlockEntity> PLATFORM_CORE =
            register("platform_core",
                    FabricBlockEntityTypeBuilder.create(PlatformCoreBlockEntity::new, ModBlocks.PLATFORM_CORE).build());

    public static final class_2591<LineControlPanelBlockEntity> LINE_CONTROL_PANEL =
            register("line_control_panel",
                    FabricBlockEntityTypeBuilder.create(LineControlPanelBlockEntity::new, ModBlocks.LINE_CONTROL_PANEL).build());

    public static final class_2591<MetroSignalBlockEntity> METRO_SIGNAL =
            register("metro_signal",
                    FabricBlockEntityTypeBuilder.create(MetroSignalBlockEntity::new, ModBlocks.METRO_SIGNAL).build());

    public static final class_2591<RedstoneLogicBlockEntity> REDSTONE_LOGIC =
            register("redstone_logic",
                    FabricBlockEntityTypeBuilder.create(RedstoneLogicBlockEntity::new, ModBlocks.REDSTONE_LOGIC).build());

    public static void register() {
        // 引用本类即触发静态初始化 → 完成方块实体类型注册。
    }

    private static <T extends class_2586> class_2591<T> register(String name, class_2591<T> type) {
        return class_2378.method_10230(class_7923.field_41181, class_2960.method_60655(VanillaPlusMetro.MOD_ID, name), type);
    }
}
