package com.vanillaplus.metro.registry;

import com.vanillaplus.metro.VanillaPlusMetro;
import com.vanillaplus.metro.block.BlueRedstoneWireBlock;
import com.vanillaplus.metro.block.LineControlPanelBlock;
import com.vanillaplus.metro.block.MetroSignalBlock;
import com.vanillaplus.metro.block.PlatformCoreBlock;
import com.vanillaplus.metro.block.RedstoneLogicBlock;
import com.vanillaplus.metro.block.ScreenDoorBlock;
import com.vanillaplus.metro.block.TurnstileBlock;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_2766;
import net.minecraft.class_2960;
import net.minecraft.class_3619;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import net.minecraft.class_7706;
import net.minecraft.class_7923;

public final class ModBlocks {
    private ModBlocks() {}

    /** 站台核心块：铺在铁轨正下方，带方块实体存储 GUI 参数（停车时间/加速度/巡航速度）。 */
    public static final class_2248 PLATFORM_CORE = register("platform_core",
            new PlatformCoreBlock(class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_15978)
                    .method_51368(class_2766.field_12653)
                    .method_9629(1.5F, 6.0F)
                    .method_29292()
                    .method_9626(class_2498.field_11544)));

    /** 现代屏蔽门：2 格高框架玻璃面板——只能由系统/红石开启，玩家无法徒手打开。 */
    public static final class_2248 SCREEN_DOOR = register("screen_door",
            new ScreenDoorBlock(class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_15979)
                    .method_9632(0.5F)
                    .method_22488()
                    .method_50012(class_3619.field_15971)
                    .method_9626(class_2498.field_11533)));

    /** 地铁闸机：1 格高，默认关闭；右键消耗车票（绿宝石）或红石信号开启，过后自动关闭。 */
    public static final class_2248 TURNSTILE = register("turnstile",
            new TurnstileBlock(class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_16005)
                    .method_9632(1.0F)
                    .method_22488()
                    .method_29292()
                    .method_9626(class_2498.field_11533)));

    /** 线路总控面板：统筹整条线路的寻路检测与调度。 */
    public static final class_2248 LINE_CONTROL_PANEL = register("line_control_panel",
            new LineControlPanelBlock(class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_15984)
                    .method_51368(class_2766.field_12645)
                    .method_9629(1.5F, 6.0F)
                    .method_29292()
                    .method_9626(class_2498.field_11533)));

    /** 现代信号灯：放在铁轨旁，红/绿灯闭塞控制；红灯时发光更亮并输出红石。 */
    public static final class_2248 METRO_SIGNAL = register("metro_signal",
            new MetroSignalBlock(class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_16009)
                    .method_9632(0.8F)
                    .method_22488()
                    .method_9626(class_2498.field_11533)
                    .method_9631(state -> state.method_11654(net.minecraft.class_2741.field_12548) ? 7 : 10)));

    /** 蓝色红石粉（方块形态）：信号强度不衰减。物品叫 blue_redstone，单独在 ModItems 注册。 */
    public static final class_2248 BLUE_REDSTONE_WIRE = registerBlockOnly("blue_redstone_wire",
            new BlueRedstoneWireBlock(class_4970.class_2251.method_9630(class_2246.field_10091)));

    /** 5 出 1 入 可编程红石块。 */
    public static final class_2248 REDSTONE_LOGIC = register("redstone_logic",
            new RedstoneLogicBlock(class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_16009)
                    .method_9632(1.5F)
                    .method_29292()
                    .method_9626(class_2498.field_11544)));

    public static void register() {
        // 引用本类即触发上面的静态初始化 → 完成方块注册。
        // 追加到创造模式「红石」标签页（与铁轨/矿车同属交通/红石类）。
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40198).register(entries -> {
            entries.method_45421(PLATFORM_CORE);
            entries.method_45421(SCREEN_DOOR);
            entries.method_45421(TURNSTILE);
            entries.method_45421(LINE_CONTROL_PANEL);
            entries.method_45421(METRO_SIGNAL);
            entries.method_45421(REDSTONE_LOGIC);
        });
    }

    private static class_2248 register(String name, class_2248 block) {
        class_2960 id = class_2960.method_60655(VanillaPlusMetro.MOD_ID, name);
        class_2378.method_10230(class_7923.field_41178, id, new class_1747(block, new class_1792.class_1793()));
        return class_2378.method_10230(class_7923.field_41175, id, block);
    }

    /** 只注册方块、不自动建物品（物品另行命名注册）。 */
    private static class_2248 registerBlockOnly(String name, class_2248 block) {
        return class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(VanillaPlusMetro.MOD_ID, name), block);
    }
}
