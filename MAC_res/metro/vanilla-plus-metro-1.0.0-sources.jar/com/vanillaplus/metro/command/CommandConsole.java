package com.vanillaplus.metro.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.vanillaplus.metro.program.ProgrammableController;
import com.vanillaplus.metro.registry.ModItems;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_2168;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;

/**
 * 指令控制台的服务端逻辑：注册网络包，接收客户端脚本并逐行执行（用玩家自身权限），结果回传界面。
 *
 * 空行、以 # 或 // 开头的行会被跳过（注释）；行首的 / 可有可无。
 */
public final class CommandConsole {
    private CommandConsole() {}

    private static final int MAX_OUTPUT = 30000;

    /** 在通用初始化中调用：注册网络包类型（两端都需）与服务端接收器。 */
    public static void register() {
        PayloadTypeRegistry.playC2S().register(RunCommandsPayload.ID, RunCommandsPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(CommandResultPayload.ID, CommandResultPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(OpenEditorPayload.ID, OpenEditorPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(SaveProgramPayload.ID, SaveProgramPayload.CODEC);

        // 临时指令控制台：客户端脚本 → 逐行执行
        ServerPlayNetworking.registerGlobalReceiver(RunCommandsPayload.ID, (payload, context) -> {
            class_3222 player = context.player();
            MinecraftServer server = player.method_5682();
            if (server == null) {
                return;
            }
            server.execute(() -> {
                String result = executeScript(server, player, payload.script());
                ServerPlayNetworking.send(player, new CommandResultPayload(result));
            });
        });

        // 保存程序到可编程方块（解析校验 + 存 NBT + 自动启用编程模式）
        ServerPlayNetworking.registerGlobalReceiver(SaveProgramPayload.ID, (payload, context) -> {
            class_3222 player = context.player();
            MinecraftServer server = player.method_5682();
            if (server == null) {
                return;
            }
            server.execute(() -> {
                String result;
                class_2586 be = player.method_37908().method_8321(payload.pos());
                if (be instanceof ProgrammableController core) {
                    String err = core.setProgram(payload.program());
                    if (err == null) {
                        core.setProgramMode(true);
                        result = "§a已保存并启用编程模式 ✔";
                    } else {
                        result = "§c语法错误：" + err;
                    }
                } else {
                    result = "§c目标方块不可编程";
                }
                ServerPlayNetworking.send(player, new CommandResultPayload(result));
            });
        });

        // 手持「指令平板」右键可编程方块 → 打开它的编程界面（拦截默认右键 / 临时控制台）
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (hand != class_1268.field_5808 || !player.method_5998(hand).method_31574(ModItems.COMMAND_TABLET)) {
                return class_1269.field_5811;
            }
            class_2338 p = hit.method_17777();
            if (!(world.method_8321(p) instanceof ProgrammableController core)) {
                return class_1269.field_5811;
            }
            if (!world.field_9236 && player instanceof class_3222 sp) {
                java.util.List<String> cat = new java.util.ArrayList<>(
                        java.util.List.of("on", "if", "else", "and", "or", "not", "true", "false"));
                cat.addAll(core.apiCatalog());
                ServerPlayNetworking.send(sp, new OpenEditorPayload(p, core.getProgram(), String.join(" ", cat), core.bindingsInfo()));
            }
            return class_1269.field_5812; // 消费交互
        });
    }

    private static String executeScript(MinecraftServer server, class_3222 player, String script) {
        class_2168 source = player.method_5671(); // 沿用玩家自身权限等级
        var dispatcher = server.method_3734().method_9235();

        String[] lines = script.split("\n", -1);
        StringBuilder out = new StringBuilder();
        int ok = 0, fail = 0, lineNo = 0;

        for (String raw : lines) {
            lineNo++;
            String line = raw.strip();
            if (line.isEmpty() || line.startsWith("#") || line.startsWith("//")) {
                continue;
            }
            String cmd = line.startsWith("/") ? line.substring(1) : line;
            try {
                dispatcher.execute(cmd, source);
                ok++;
                out.append("§a✓ §7#").append(lineNo).append("§r ").append(line).append('\n');
            } catch (CommandSyntaxException e) {
                fail++;
                out.append("§c✗ §7#").append(lineNo).append("§r ").append(e.getMessage()).append('\n');
            } catch (Exception e) {
                fail++;
                out.append("§c✗ §7#").append(lineNo).append("§r ").append(String.valueOf(e.getMessage())).append('\n');
            }
        }

        String header = "共执行 " + (ok + fail) + " 条：§a" + ok + " 成功§r / §c" + fail + " 失败§r\n";
        out.insert(0, header);
        if (out.length() > MAX_OUTPUT) {
            out.setLength(MAX_OUTPUT);
            out.append("\n…（输出过长已截断）");
        }
        return out.toString();
    }
}
