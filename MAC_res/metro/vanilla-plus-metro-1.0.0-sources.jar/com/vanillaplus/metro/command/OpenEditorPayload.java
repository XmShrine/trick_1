package com.vanillaplus.metro.command;

import com.vanillaplus.metro.VanillaPlusMetro;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * 服务端 → 客户端：为某个可编程方块打开编程界面。
 * program=当前程序；catalog=可用候选词(空格分隔)；bindings=已绑定清单(每行"类型:名字")。
 */
public record OpenEditorPayload(class_2338 pos, String program, String catalog, String bindings) implements class_8710 {

    public static final class_8710.class_9154<OpenEditorPayload> ID =
            new class_8710.class_9154<>(class_2960.method_60655(VanillaPlusMetro.MOD_ID, "open_editor"));

    public static final class_9139<class_9129, OpenEditorPayload> CODEC = class_9139.method_56905(
            class_2338.field_48404, OpenEditorPayload::pos,
            class_9135.field_48554, OpenEditorPayload::program,
            class_9135.field_48554, OpenEditorPayload::catalog,
            class_9135.field_48554, OpenEditorPayload::bindings,
            OpenEditorPayload::new);

    @Override
    public class_8710.class_9154<OpenEditorPayload> method_56479() {
        return ID;
    }
}
