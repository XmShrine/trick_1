package com.vanillaplus.metro.command;

import com.vanillaplus.metro.VanillaPlusMetro;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * 客户端 → 服务端：请求执行一段多行指令脚本。
 */
public record RunCommandsPayload(String script) implements class_8710 {

    public static final class_8710.class_9154<RunCommandsPayload> ID =
            new class_8710.class_9154<>(class_2960.method_60655(VanillaPlusMetro.MOD_ID, "run_commands"));

    public static final class_9139<class_9129, RunCommandsPayload> CODEC =
            class_9139.method_56434(class_9135.field_48554, RunCommandsPayload::script, RunCommandsPayload::new);

    @Override
    public class_8710.class_9154<RunCommandsPayload> method_56479() {
        return ID;
    }
}
