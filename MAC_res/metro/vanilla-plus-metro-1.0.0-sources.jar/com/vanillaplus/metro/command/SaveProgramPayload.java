package com.vanillaplus.metro.command;

import com.vanillaplus.metro.VanillaPlusMetro;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/** 客户端 → 服务端：把编辑好的程序保存到某个可编程方块。 */
public record SaveProgramPayload(class_2338 pos, String program) implements class_8710 {

    public static final class_8710.class_9154<SaveProgramPayload> ID =
            new class_8710.class_9154<>(class_2960.method_60655(VanillaPlusMetro.MOD_ID, "save_program"));

    public static final class_9139<class_9129, SaveProgramPayload> CODEC = class_9139.method_56435(
            class_2338.field_48404, SaveProgramPayload::pos,
            class_9135.field_48554, SaveProgramPayload::program,
            SaveProgramPayload::new);

    @Override
    public class_8710.class_9154<SaveProgramPayload> method_56479() {
        return ID;
    }
}
