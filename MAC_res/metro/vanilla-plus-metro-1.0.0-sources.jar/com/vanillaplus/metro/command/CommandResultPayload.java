package com.vanillaplus.metro.command;

import com.vanillaplus.metro.VanillaPlusMetro;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * 服务端 → 客户端：把逐行执行结果回传给指令控制台界面显示。
 */
public record CommandResultPayload(String result) implements class_8710 {

    public static final class_8710.class_9154<CommandResultPayload> ID =
            new class_8710.class_9154<>(class_2960.method_60655(VanillaPlusMetro.MOD_ID, "command_result"));

    public static final class_9139<class_9129, CommandResultPayload> CODEC =
            class_9139.method_56434(class_9135.field_48554, CommandResultPayload::result, CommandResultPayload::new);

    @Override
    public class_8710.class_9154<CommandResultPayload> method_56479() {
        return ID;
    }
}
