package com.vanillaplus.metro.item;

import net.minecraft.class_1792;

/**
 * 信号配置器 (Signal Configurator)。
 *
 * 用法：右键点击一盏「现代信号灯」→ 再右键点击「线路总控面板」，即把该信号灯注册到该线路。
 * 交互逻辑集中在 {@link com.vanillaplus.metro.metro.SignalBinding}。
 */
public class SignalConfiguratorItem extends class_1792 {
    public SignalConfiguratorItem(class_1793 settings) {
        super(settings);
    }
}
