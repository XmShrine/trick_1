package com.vanillaplus.metro.item;

import net.minecraft.class_1792;

/**
 * 连挂棒 (Coupler)。
 *
 * 用法：
 *  - 右键先后点击两辆矿车 → 将其连挂为「列车组」（第二次点击的车厢挂在第一次的后面）。
 *  - 潜行 + 右键单节车厢 → 解除该车厢的连挂。
 *
 * 实际交互逻辑集中在 {@link com.vanillaplus.metro.coupling.CouplingHandler}
 * （通过 Fabric 的 UseEntityCallback 统一处理），本类目前仅作为物品载体。
 */
public class CouplerItem extends class_1792 {
    public CouplerItem(class_1793 settings) {
        super(settings);
    }
}
