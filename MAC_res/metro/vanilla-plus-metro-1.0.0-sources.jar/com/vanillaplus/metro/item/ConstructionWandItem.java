package com.vanillaplus.metro.item;

import com.vanillaplus.metro.registry.ModItems;
import com.vanillaplus.metro.track.TrackBuilder;
import com.vanillaplus.metro.track.TrackProfile;
import com.vanillaplus.metro.track.TrackProfiles;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * 施工法杖 (Construction Wand)：多点折线自动生成轨道基建（地面/隧道/高架），支持 90°转角、坡道。
 *
 * 操作：
 *  - 右键方块          = 添加一个「路点」（会自动与上一个路点拉直成正东西/正南北，不必点准）。
 *  - 左键方块          = 一键清空所有路点。
 *  - 潜行 + 右键方块   = 切换轨道样式（地面路基 / 标准隧道 / 高架桥）。
 *  - 右键空气          = 切换「坡度」开关（关闭时无视终点高度，强制水平）。
 *  - 潜行 + 右键空气   = 开建（把所有路点用直线+转角连起来）。
 *
 * 说明：折线各段轴对齐；每段可独立上下坡（≤1:1），转角两侧各留 1 格缓冲保持水平。
 */
public class ConstructionWandItem extends class_1792 {

    private static final int MAX_WAYPOINTS = 64;

    private static final Map<UUID, List<class_2338>> WAYPOINTS = new HashMap<>();
    private static final Map<UUID, Integer> PROFILE_IDX = new HashMap<>();
    private static final Map<UUID, Boolean> SLOPE_ENABLED = new HashMap<>();

    public ConstructionWandItem(class_1793 settings) {
        super(settings);
    }

    /** 注册「左键清空路点」手势（在主入口调用一次）。 */
    public static void registerClearGesture() {
        AttackBlockCallback.EVENT.register((player, world, hand, pos, direction) -> {
            if (world.field_9236 || !player.method_5998(hand).method_31574(ModItems.CONSTRUCTION_WAND)) {
                return class_1269.field_5811;
            }
            List<class_2338> pts = WAYPOINTS.remove(player.method_5667());
            int cleared = pts == null ? 0 : pts.size();
            player.method_7353(class_2561.method_43470(cleared > 0 ? "已清空 " + cleared + " 个路点" : "路点已是空的")
                    .method_27692(class_124.field_1065), true);
            return class_1269.field_5814; // 拦截破坏方块
        });
    }

    // 右键方块：加路点；潜行则切样式
    @Override
    public class_1269 method_7884(class_1838 ctx) {
        class_1937 world = ctx.method_8045();
        class_1657 player = ctx.method_8036();
        if (world.field_9236 || player == null) {
            return class_1269.field_5812;
        }
        UUID pid = player.method_5667();
        int size = TrackProfiles.ALL.size();
        int idx = Math.floorMod(PROFILE_IDX.getOrDefault(pid, 0), size);

        if (player.method_5715()) {
            idx = (idx + 1) % size;
            PROFILE_IDX.put(pid, idx);
            player.method_7353(class_2561.method_43470("轨道样式：" + TrackProfiles.ALL.get(idx).name).method_27692(class_124.field_1075), true);
            return class_1269.field_5812;
        }

        class_2338 rail = ctx.method_8037().method_10084(); // 轨面取所点方块上一格
        List<class_2338> pts = WAYPOINTS.computeIfAbsent(pid, k -> new ArrayList<>());
        if (pts.size() >= MAX_WAYPOINTS) {
            player.method_7353(class_2561.method_43470("路点已达上限 " + MAX_WAYPOINTS + "，请先开建").method_27692(class_124.field_1061), true);
            return class_1269.field_5812;
        }
        class_2338 snapped = pts.isEmpty() ? rail : snapToAxis(pts.get(pts.size() - 1), rail);
        pts.add(snapped);
        player.method_7353(class_2561.method_43470("路点 #" + pts.size() + " " + snapped.method_23854()
                + "（潜行+右键空气 开建 / 左键清空）").method_27692(class_124.field_1075), true);
        return class_1269.field_5812;
    }

    // 右键空气：潜行=开建；否则切坡度
    @Override
    public class_1271<class_1799> method_7836(class_1937 world, class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);
        if (world.field_9236) {
            return class_1271.method_22427(stack);
        }
        UUID pid = player.method_5667();

        if (player.method_5715()) {
            List<class_2338> pts = WAYPOINTS.get(pid);
            if (pts == null || pts.size() < 2) {
                WAYPOINTS.remove(pid);
                player.method_7353(class_2561.method_43470("路点不足 2 个，已清空").method_27692(class_124.field_1080), true);
                return class_1271.method_22427(stack);
            }
            int idx = Math.floorMod(PROFILE_IDX.getOrDefault(pid, 0), TrackProfiles.ALL.size());
            TrackProfile profile = TrackProfiles.ALL.get(idx);
            boolean slope = SLOPE_ENABLED.getOrDefault(pid, true);
            TrackBuilder.Result result = TrackBuilder.build((class_3218) world, pts, slope, profile);
            player.method_7353(class_2561.method_43470(result.message()).method_27692(result.ok() ? class_124.field_1060 : class_124.field_1061), false);
            if (result.ok()) {
                WAYPOINTS.remove(pid);
            }
            return class_1271.method_22427(stack);
        }

        boolean enabled = !SLOPE_ENABLED.getOrDefault(pid, true);
        SLOPE_ENABLED.put(pid, enabled);
        player.method_7353(class_2561.method_43470("坡度：" + (enabled ? "开（随终点高度上下坡）" : "关（强制水平）"))
                .method_27692(enabled ? class_124.field_1075 : class_124.field_1065), true);
        return class_1271.method_22427(stack);
    }

    /** 把新点沿主轴拉直到与上一个路点同一直线（保留新点的高度）。 */
    private static class_2338 snapToAxis(class_2338 prev, class_2338 click) {
        int dx = click.method_10263() - prev.method_10263();
        int dz = click.method_10260() - prev.method_10260();
        if (Math.abs(dx) >= Math.abs(dz)) {
            return new class_2338(click.method_10263(), click.method_10264(), prev.method_10260()); // 正东西
        }
        return new class_2338(prev.method_10263(), click.method_10264(), click.method_10260());     // 正南北
    }
}
