package com.vanillaplus.metro.metro;

import com.vanillaplus.metro.registry.ModAttachments;
import net.fabricmc.fabric.api.attachment.v1.AttachmentTarget;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1297;
import net.minecraft.class_1688;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import net.minecraft.class_5321;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * 列车自带区块加载（特性五）。
 *
 * 每秒扫描每个世界里“属于列车组”的矿车（连挂的跟随者及其前车），把它们所在及相邻的区块强制加载，
 * 确保无人驾驶的自动列车跨越远距离、经过原本未加载区块时不会卡死或消失。列车离开后自动解除强制加载。
 */
public final class TrainChunkLoader {
    private TrainChunkLoader() {}

    /** 每辆列车周围强制加载的区块半径（0=仅本区块，1=3x3）。 */
    private static final int CHUNK_RADIUS = 1;
    private static final int SCAN_INTERVAL = 20; // 每 20 tick（1 秒）扫描一次

    /** 每个世界当前由本模组强制加载的区块集合（打包成 long）。 */
    private static final Map<class_5321<class_1937>, Set<Long>> FORCED = new HashMap<>();
    private static int tickCounter = 0;

    public static void register() {
        ServerTickEvents.END_WORLD_TICK.register(TrainChunkLoader::onWorldTick);
    }

    private static void onWorldTick(class_3218 world) {
        if (++tickCounter % SCAN_INTERVAL != 0) {
            return;
        }

        // 1) 收集所有列车矿车（跟随者）及其引用的前车 UUID
        Set<UUID> leaderIds = new HashSet<>();
        for (class_1297 e : world.method_27909()) {
            if (e instanceof class_1688 cart) {
                UUID follow = ((AttachmentTarget) cart).getAttached(ModAttachments.FOLLOW_TARGET);
                if (follow != null) {
                    leaderIds.add(follow);
                }
            }
        }

        // 2) 计算需要强制加载的目标区块：跟随者 + 前车 所在及相邻区块
        Set<Long> desired = new HashSet<>();
        for (class_1297 e : world.method_27909()) {
            if (!(e instanceof class_1688 cart)) {
                continue;
            }
            boolean isFollower = ((AttachmentTarget) cart).getAttached(ModAttachments.FOLLOW_TARGET) != null;
            boolean isLeader = leaderIds.contains(cart.method_5667());
            if (!isFollower && !isLeader) {
                continue;
            }
            class_1923 cp = new class_1923(cart.method_24515());
            for (int dx = -CHUNK_RADIUS; dx <= CHUNK_RADIUS; dx++) {
                for (int dz = -CHUNK_RADIUS; dz <= CHUNK_RADIUS; dz++) {
                    desired.add(class_1923.method_8331(cp.field_9181 + dx, cp.field_9180 + dz));
                }
            }
        }

        // 3) 与当前强制集合做差异，增量地加/卸强制加载
        Set<Long> forced = FORCED.computeIfAbsent(world.method_27983(), k -> new HashSet<>());

        for (long c : desired) {
            if (!forced.contains(c)) {
                world.method_17988(class_1923.method_8325(c), class_1923.method_8332(c), true);
            }
        }
        for (long c : forced) {
            if (!desired.contains(c)) {
                world.method_17988(class_1923.method_8325(c), class_1923.method_8332(c), false);
            }
        }

        forced.clear();
        forced.addAll(desired);
    }
}
