package com.vanillaplus.metro.metro;

import com.vanillaplus.metro.block.entity.LineControlPanelBlockEntity;
import com.vanillaplus.metro.registry.ModBlocks;
import com.vanillaplus.metro.registry.ModItems;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * 信号配置器的绑定交互：右键信号灯 → 右键线路总控面板，把信号灯注册到该线路。
 */
public final class SignalBinding {
    private SignalBinding() {}

    /** 玩家 -> 已选中的信号灯位置。 */
    private static final Map<UUID, class_2338> SELECTED = new HashMap<>();
    /** 玩家 -> 上次处理刻，去重（回避回调重复触发）。 */
    private static final Map<UUID, Long> LAST_TICK = new HashMap<>();

    public static void register() {
        UseBlockCallback.EVENT.register(SignalBinding::onUseBlock);
    }

    private static class_1269 onUseBlock(class_1657 player, class_1937 world, class_1268 hand, class_3965 hit) {
        if (world.field_9236) return class_1269.field_5811;
        if (hand != class_1268.field_5808) return class_1269.field_5811;
        if (!player.method_5998(hand).method_31574(ModItems.SIGNAL_CONFIGURATOR)) return class_1269.field_5811;

        class_2338 pos = hit.method_17777();
        class_2680 state = world.method_8320(pos);
        UUID pid = player.method_5667();

        long now = world.method_8510();
        Long last = LAST_TICK.get(pid);
        if (last != null && last == now) {
            return class_1269.field_5812;
        }
        LAST_TICK.put(pid, now);

        if (state.method_27852(ModBlocks.METRO_SIGNAL)) {
            SELECTED.put(pid, pos.method_10062());
            player.method_7353(class_2561.method_43470("已选择信号灯 " + pos.method_23854() + "，请右键线路总控面板完成注册")
                    .method_27692(class_124.field_1075), true);
            return class_1269.field_5812;
        }

        if (state.method_27852(ModBlocks.LINE_CONTROL_PANEL)) {
            class_2338 sig = SELECTED.remove(pid);
            if (sig == null) {
                player.method_7353(class_2561.method_43470("请先右键一盏信号灯，再点面板").method_27692(class_124.field_1054), true);
                return class_1269.field_5812;
            }
            if (world.method_8321(pos) instanceof LineControlPanelBlockEntity be) {
                be.bindSignal(sig);
                player.method_7353(class_2561.method_43470("已将信号灯 " + sig.method_23854() + " 注册到本线路")
                        .method_27692(class_124.field_1060), true);
            }
            return class_1269.field_5812;
        }

        return class_1269.field_5811;
    }
}
