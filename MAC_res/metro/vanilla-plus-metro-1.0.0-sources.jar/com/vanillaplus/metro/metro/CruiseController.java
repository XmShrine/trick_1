package com.vanillaplus.metro.metro;

import com.vanillaplus.metro.registry.ModAttachments;
import net.fabricmc.fabric.api.attachment.v1.AttachmentTarget;
import net.minecraft.class_1688;
import net.minecraft.class_2241;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2768;
import net.minecraft.class_3218;

/**
 * 巡航自驱：让带有巡航速度（CRUISE_SPEED）的“列车头”持续维持该速度，并在弯道前自动减速。
 *
 * 原版矿车在平直无动力铁轨上会因摩擦持续减速，仅靠站台发车那一下无法维持巡航；
 * 且巡航速度远超原版 0.4/tick 的过弯安全上限，高速直冲弯道会被甩飞。
 * 因此这里每 tick：
 *  1) 前视扫描轨道，探测最近弯道的距离，据此把“目标速度”从巡航平滑降到过弯安全速度；
 *  2) 让速度追赶目标——低了加速、高了减速——从而做到进弯减速、出弯提速。
 * getMaxSpeed 的 Mixin 仍保证不超过巡航上限。
 *
 * 仅作用于带巡航属性的“列车头”，不影响普通矿车、连挂跟随、信号等其它逻辑。
 */
public final class CruiseController {
    private CruiseController() {}

    private static final double MAINTAIN_ACCEL = 0.05D; // 每 tick 追赶目标的加速度
    private static final double MAINTAIN_DECEL = 0.08D;  // 每 tick 追赶目标的减速度
    private static final double MIN_MOVING_SPEED = 0.02D;
    private static final double CURVE_SAFE_SPEED = 0.35D; // 过弯安全速度（略低于原版 0.4）
    private static final int CURVE_LOOKAHEAD = 10;        // 前视多少段轨道找弯道

    public static void maintain(class_1688 cart) {
        if (!(cart.method_37908() instanceof class_3218 world) || cart.method_31481()) {
            return;
        }
        AttachmentTarget t = (AttachmentTarget) cart;
        if (t.getAttached(ModAttachments.FOLLOW_TARGET) != null) {
            return; // 仅列车头；后续车厢由连挂跟随
        }
        Double cruise = t.getAttached(ModAttachments.CRUISE_SPEED);
        if (cruise == null || cruise <= 0.0D) {
            return;
        }
        Long suppressUntil = t.getAttached(ModAttachments.CRUISE_SUPPRESS_UNTIL);
        if (suppressUntil != null && world.method_8510() <= suppressUntil) {
            return; // 正被站台/信号接管制动
        }

        class_243 v = cart.method_18798();
        double hs = Math.hypot(v.field_1352, v.field_1350);
        if (hs < MIN_MOVING_SPEED) {
            return; // 已停下：需要站台/信号给出起步初速后再自驱
        }
        class_2338 railPos = railUnder(world, cart);
        if (railPos == null) {
            return; // 不在铁轨上：不自驱，避免脱轨后乱跑
        }

        // 目标速度：巡航速度；若前方有弯道则按距离压低到过弯安全速度
        double target = cruise;
        int curveDist = curveDistanceAhead(world, railPos, v, CURVE_LOOKAHEAD);
        if (curveDist < CURVE_LOOKAHEAD) {
            double factor = (double) curveDist / CURVE_LOOKAHEAD; // 0=在弯道, 1=很远
            double curveTarget = CURVE_SAFE_SPEED + (cruise - CURVE_SAFE_SPEED) * factor;
            target = Math.min(target, curveTarget);
        }

        double next;
        if (hs < target) {
            next = Math.min(target, hs + MAINTAIN_ACCEL);
        } else {
            next = Math.max(target, hs - MAINTAIN_DECEL);
        }
        if (Math.abs(next - hs) > 1.0E-6D) {
            double scale = next / hs; // 保持方向不变，只调整速度大小
            cart.method_18800(v.field_1352 * scale, v.field_1351, v.field_1350 * scale);
            cart.field_6037 = true;
        }
    }

    /** 供站台/信号调用：抑制该车的巡航自驱若干 tick（每 tick 刷新即可持续抑制）。 */
    public static void suppress(class_1688 cart, class_3218 world, int ticks) {
        ((AttachmentTarget) cart).setAttached(ModAttachments.CRUISE_SUPPRESS_UNTIL, world.method_8510() + ticks);
    }

    // ------------------------------------------------------------------
    // 弯道前视
    // ------------------------------------------------------------------

    /** 沿行进方向前视，返回最近弯道的段数（0=当前就在弯道），无弯道则返回 lookahead。 */
    private static int curveDistanceAhead(class_3218 world, class_2338 railPos, class_243 velocity, int lookahead) {
        if (isCurve(world.method_8320(railPos))) {
            return 0;
        }
        class_2350 dir = dominantDir(velocity);
        if (dir == null) {
            return lookahead;
        }
        class_2338 prev = railPos;
        class_2338 cur = RailPathfinder.railInDirection(world, railPos, dir);
        int dist = 1;
        while (cur != null && dist <= lookahead) {
            if (isCurve(world.method_8320(cur))) {
                return dist;
            }
            class_2338 forward = pickForward(world, cur, prev);
            prev = cur;
            cur = forward;
            dist++;
        }
        return lookahead;
    }

    /** 从 cur 的相邻铁轨里挑一个“不是来路 prev”的作为前进方向。 */
    private static class_2338 pickForward(class_3218 world, class_2338 cur, class_2338 prev) {
        for (class_2338 n : RailPathfinder.neighborsOf(world, cur)) {
            if (!n.equals(prev)) {
                return n;
            }
        }
        return null;
    }

    private static boolean isCurve(class_2680 state) {
        if (!(state.method_26204() instanceof class_2241) || !state.method_28498(class_2741.field_12507)) {
            return false;
        }
        class_2768 shape = state.method_11654(class_2741.field_12507);
        return shape == class_2768.field_12663 || shape == class_2768.field_12672
                || shape == class_2768.field_12664 || shape == class_2768.field_12671;
    }

    private static class_2338 railUnder(class_3218 world, class_1688 cart) {
        class_2338 at = cart.method_24515();
        if (world.method_8320(at).method_26204() instanceof class_2241) {
            return at;
        }
        class_2338 below = at.method_10074();
        if (world.method_8320(below).method_26204() instanceof class_2241) {
            return below;
        }
        return null;
    }

    private static class_2350 dominantDir(class_243 v) {
        if (Math.abs(v.field_1352) < 1.0E-4D && Math.abs(v.field_1350) < 1.0E-4D) {
            return null;
        }
        if (Math.abs(v.field_1352) >= Math.abs(v.field_1350)) {
            return v.field_1352 > 0 ? class_2350.field_11034 : class_2350.field_11039;
        }
        return v.field_1350 > 0 ? class_2350.field_11035 : class_2350.field_11043;
    }
}
