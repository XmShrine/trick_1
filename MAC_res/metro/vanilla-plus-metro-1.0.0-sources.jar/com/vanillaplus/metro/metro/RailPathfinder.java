package com.vanillaplus.metro.metro;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.BiPredicate;
import net.minecraft.class_1937;
import net.minecraft.class_2241;
import net.minecraft.class_2338;
import net.minecraft.class_2350;

/**
 * 沿原版铁轨做广度优先搜索（BFS）的拓扑检测器（特性四）。
 *
 * 铁轨连通规则：从一段铁轨出发，检查 4 个水平方向的相邻格，以及其上一格（上坡）、下一格（下坡）
 * 是否也是铁轨——覆盖平直、拐弯与坡道。BFS 遍历整个连通的铁轨网络，并可沿途识别站台。
 */
public final class RailPathfinder {
    private RailPathfinder() {}

    public static final int DEFAULT_MAX_RAILS = 4096;

    /** 一次网络扫描的结果。 */
    public record NetworkScan(Set<class_2338> rails, List<class_2338> stations, boolean capped) {}

    public static boolean isRail(class_1937 world, class_2338 pos) {
        return world.method_8320(pos).method_26204() instanceof class_2241;
    }

    /** 在中心点周围由近及远搜索一段铁轨作为 BFS 起点。 */
    public static class_2338 findNearbyRail(class_1937 world, class_2338 center, int radius) {
        for (int r = 0; r <= radius; r++) {
            for (int dx = -r; dx <= r; dx++) {
                for (int dy = -r; dy <= r; dy++) {
                    for (int dz = -r; dz <= r; dz++) {
                        if (Math.max(Math.abs(dx), Math.max(Math.abs(dy), Math.abs(dz))) != r) {
                            continue; // 只看当前“壳层”，保证由近及远
                        }
                        class_2338 p = center.method_10069(dx, dy, dz);
                        if (isRail(world, p)) {
                            return p.method_10062();
                        }
                    }
                }
            }
        }
        return null;
    }

    /**
     * 从 startRail 出发 BFS 遍历整个铁轨连通网络。
     *
     * @param stationTest 判定某段铁轨是否为站台（例如其正下方是站台核心块）
     * @param maxRails    遍历上限，超过则标记 capped（防止极长线路卡死）
     */
    public static NetworkScan scan(class_1937 world, class_2338 startRail, int maxRails,
                                   BiPredicate<class_1937, class_2338> stationTest) {
        Set<class_2338> visited = new HashSet<>();
        List<class_2338> stations = new ArrayList<>();
        Deque<class_2338> queue = new ArrayDeque<>();

        class_2338 start = startRail.method_10062();
        visited.add(start);
        queue.add(start);
        boolean capped = false;

        while (!queue.isEmpty()) {
            if (visited.size() > maxRails) {
                capped = true;
                break;
            }
            class_2338 cur = queue.poll();
            if (stationTest.test(world, cur)) {
                stations.add(cur);
            }
            for (class_2338 n : neighbors(world, cur)) {
                if (visited.add(n)) {
                    queue.add(n);
                }
            }
        }
        return new NetworkScan(visited, stations, capped);
    }

    /** 判断 a、b 两段铁轨是否连通（从 a BFS 能否到达 b）。 */
    public static boolean isConnected(class_1937 world, class_2338 a, class_2338 b, int maxRails) {
        if (!isRail(world, a) || !isRail(world, b)) {
            return false;
        }
        Set<class_2338> visited = new HashSet<>();
        Deque<class_2338> queue = new ArrayDeque<>();
        class_2338 start = a.method_10062();
        class_2338 target = b.method_10062();
        visited.add(start);
        queue.add(start);
        while (!queue.isEmpty() && visited.size() <= maxRails) {
            class_2338 cur = queue.poll();
            if (cur.equals(target)) {
                return true;
            }
            for (class_2338 n : neighbors(world, cur)) {
                if (visited.add(n)) {
                    queue.add(n);
                }
            }
        }
        return false;
    }

    /** 公开版：返回某段铁轨的相邻铁轨（含上下坡）。供信号灯区间扫描复用。 */
    public static List<class_2338> neighborsOf(class_1937 world, class_2338 rail) {
        return neighbors(world, rail);
    }

    /** 沿某方向取相邻的一段铁轨（含上/下坡），没有则返回 null。 */
    public static class_2338 railInDirection(class_1937 world, class_2338 rail, class_2350 dir) {
        class_2338 flat = rail.method_10093(dir);
        if (isRail(world, flat)) return flat.method_10062();
        if (isRail(world, flat.method_10084())) return flat.method_10084();
        if (isRail(world, flat.method_10074())) return flat.method_10074();
        return null;
    }

    private static List<class_2338> neighbors(class_1937 world, class_2338 rail) {
        List<class_2338> out = new ArrayList<>(12);
        for (class_2350 d : class_2350.class_2353.field_11062) {
            class_2338 flat = rail.method_10093(d);
            addIfRail(world, flat, out);
            addIfRail(world, flat.method_10084(), out);   // 上坡
            addIfRail(world, flat.method_10074(), out); // 下坡
        }
        return out;
    }

    private static void addIfRail(class_1937 world, class_2338 pos, List<class_2338> out) {
        if (isRail(world, pos)) {
            out.add(pos.method_10062());
        }
    }
}
