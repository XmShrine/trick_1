package com.vanillaplus.metro.metro;

import com.vanillaplus.metro.VanillaPlusMetro;
import com.vanillaplus.metro.registry.ModAttachments;
import net.fabricmc.fabric.api.attachment.v1.AttachmentTarget;
import net.minecraft.class_1688;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import java.util.List;
import java.util.UUID;

/**
 * 防卡死机制（特性五）。
 *
 * 若两组列车在同一轨道上迎面/追尾逼近，触发紧急制动（双方急停），避免实体无限重叠拉扯导致服务器卡顿，
 * 并在服务器日志中记录报错。由矿车 tick（Mixin）对每辆车调用。
 */
public final class TrainSafety {
    private TrainSafety() {}

    /** 触发急停的距离阈值（格）。 */
    private static final double DANGER_DISTANCE = 1.2D;
    /** 同一坐标附近的急停日志限流。 */
    private static long lastReportTick = -1000L;

    public static void checkCollision(class_1688 cart) {
        if (!(cart.method_37908() instanceof class_3218 world) || cart.method_31481()) {
            return;
        }
        class_238 box = cart.method_5829().method_1014(0.6D);
        List<class_1688> others =
                world.method_8390(class_1688.class, box, o -> o != cart && !o.method_31481());
        if (others.isEmpty()) {
            return;
        }

        for (class_1688 other : others) {
            if (directlyCoupled(cart, other)) {
                continue; // 同一列车相邻车厢之间是正常连挂间距，不算碰撞
            }
            class_243 rel = other.method_19538().method_1020(cart.method_19538());
            double dist = rel.method_1033();
            if (dist >= DANGER_DISTANCE || dist < 1.0E-4D) {
                continue;
            }
            // 相对速度朝彼此靠近（点积 > 0）才判定为逼近
            class_243 relVel = cart.method_18798().method_1020(other.method_18798());
            if (relVel.method_1026(rel) <= 0.0D) {
                continue;
            }
            emergencyBrake(cart);
            emergencyBrake(other);
            report(world, cart);
            return;
        }
    }

    private static void emergencyBrake(class_1688 cart) {
        cart.method_18799(class_243.field_1353);
        cart.field_6037 = true;
    }

    private static void report(class_3218 world, class_1688 cart) {
        long now = world.method_8510();
        if (now - lastReportTick < 40L) {
            return; // 限流：2 秒内不重复刷屏/刷日志
        }
        lastReportTick = now;
        world.method_8396(null, cart.method_24515(), class_3417.field_14622.comp_349(),
                class_3419.field_15245, 1.0F, 0.6F);
        VanillaPlusMetro.LOGGER.warn("[防卡死] 检测到列车在 {} 附近迎面/追尾逼近，已触发紧急制动。",
                cart.method_24515().method_23854());
    }

    private static boolean directlyCoupled(class_1688 a, class_1688 b) {
        UUID aFollow = ((AttachmentTarget) a).getAttached(ModAttachments.FOLLOW_TARGET);
        UUID bFollow = ((AttachmentTarget) b).getAttached(ModAttachments.FOLLOW_TARGET);
        return b.method_5667().equals(aFollow) || a.method_5667().equals(bFollow);
    }
}
