package com.vanillaplus.metro.metro;

import com.vanillaplus.metro.program.ProgrammableController;
import com.vanillaplus.metro.registry.ModBlocks;
import com.vanillaplus.metro.registry.ModItems;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2756;
import net.minecraft.class_9334;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * 绑定工具的交互：把一个资源（当前支持屏蔽门）以某名字绑到站台核心块，供程序里 door["名"] 引用。
 *
 * 用法：在铁砧给「绑定工具」改个名字（= 绑定名）→ 右键要绑的门 → 右键站台核心块。
 */
public final class BindingHandler {
    private BindingHandler() {}

    private record Pending(String kind, class_2338 pos) {}
    private static final Map<UUID, Pending> PENDING = new HashMap<>();

    public static void register() {
        UseBlockCallback.EVENT.register(BindingHandler::onUseBlock);
    }

    private static class_1269 onUseBlock(class_1657 player, net.minecraft.class_1937 world, class_1268 hand,
                                           net.minecraft.class_3965 hit) {
        class_1799 stack = player.method_5998(hand);
        if (hand != class_1268.field_5808 || !stack.method_31574(ModItems.BINDING_TOOL)) {
            return class_1269.field_5811;
        }
        if (world.field_9236) {
            return class_1269.field_5812; // 消费交互，服务端处理
        }
        UUID pid = player.method_5667();
        class_2338 p = hit.method_17777();

        // 潜行右键控制器 → 选它作为可被 call 的资源
        if (player.method_5715() && world.method_8321(p) instanceof ProgrammableController) {
            PENDING.put(pid, new Pending("controller", p.method_10062()));
            player.method_7353(class_2561.method_43470("已选择控制器 " + p.method_23854() + "，右键另一个控制器绑定为 call 目标").method_27692(class_124.field_1075), true);
            return class_1269.field_5812;
        }

        // 点到控制器 → 完成绑定
        if (world.method_8321(p) instanceof ProgrammableController core) {
            class_2561 customName = stack.method_57824(class_9334.field_49631);
            if (customName == null) {
                player.method_7353(class_2561.method_43470("请先在铁砧给绑定工具改个名字（作为绑定名），再绑定").method_27692(class_124.field_1061), true);
                return class_1269.field_5812;
            }
            Pending pend = PENDING.remove(pid);
            if (pend == null) {
                player.method_7353(class_2561.method_43470("请先右键要绑定的资源（如屏蔽门）").method_27692(class_124.field_1054), true);
                return class_1269.field_5812;
            }
            String name = customName.getString();
            core.addBinding(name, pend.kind(), pend.pos());
            String usage = switch (pend.kind()) {
                case "door" -> "door[\"" + name + "\"].open";
                case "signal" -> "signal[\"" + name + "\"] = red";
                case "switch" -> "switch[\"" + name + "\"] = north_south";
                case "controller" -> "call(\"" + name + "\", \"事件\")";
                default -> pend.kind() + "[\"" + name + "\"]";
            };
            player.method_7353(class_2561.method_43470("已绑定 " + pend.kind() + " \"" + name + "\" → 程序里用 " + usage)
                    .method_27692(class_124.field_1060), true);
            return class_1269.field_5812;
        }

        // 点到资源 → 记为待绑定
        class_2680 s = world.method_8320(p);
        String kind = null;
        class_2338 target = p;
        if (s.method_27852(ModBlocks.SCREEN_DOOR)) {
            kind = "door";
            target = s.method_11654(class_2741.field_12533) == class_2756.field_12609 ? p.method_10074() : p;
        } else if (s.method_27852(ModBlocks.METRO_SIGNAL)) {
            kind = "signal";
        } else if (s.method_26204() instanceof net.minecraft.class_2241) {
            kind = "switch";
        }
        if (kind != null) {
            PENDING.put(pid, new Pending(kind, target.method_10062()));
            player.method_7353(class_2561.method_43470("已选择 " + kind + " " + target.method_23854() + "，右键控制器完成绑定").method_27692(class_124.field_1075), true);
            return class_1269.field_5812;
        }

        return class_1269.field_5811;
    }
}
