package com.vanillaplus.metro.coupling;

import com.vanillaplus.metro.registry.ModAttachments;
import com.vanillaplus.metro.registry.ModItems;
import net.fabricmc.fabric.api.attachment.v1.AttachmentTarget;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1688;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3532;
import net.minecraft.class_3966;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * 连挂 (Coupling) 逻辑核心。
 *
 * 数据模型：每节“跟随车厢”通过附着数据 {@link ModAttachments#FOLLOW_TARGET} 记录它要跟随的前车 UUID。
 * 由此天然形成链式列车组：C 跟随 B、B 跟随 A —— 拉动 A 即可带动整列。
 *
 * 物理：每 tick（由 {@code AbstractMinecartEntityMixin} 调用 {@link #tickFollower}）把跟随者的速度
 * 设为“前车速度 + 朝前车方向的间距修正”，从而消除原版矿车相互推挤/脱节的鬼畜表现。
 * 因为原版矿车会把速度吸附回轨道，所以即便在弯道，跟随者也会沿轨道走而不会穿地。
 */
public final class CouplingHandler {
    private CouplingHandler() {}

    /** 车厢中心目标间距（格）。矿车碰撞箱约 0.98，取 1.6 留出车厢间的小缝。 */
    private static final double GAP = 1.6D;
    /** 超过此距离视为脱节，自动解挂，避免异轨/断轨时橡皮筋式拉扯（安全兜底）。 */
    private static final double MAX_DISTANCE = 5.0D;
    /** 跟随刚度：间距误差 → 修正速度的比例系数。 */
    private static final double STIFFNESS = 0.5D;
    /** 单 tick 位置修正上限，避免瞬移/抽搐。 */
    private static final double MAX_CORRECTION = 0.35D;

    /** 玩家 UUID -> 第一次点击选中的车厢 UUID（服务器生命周期内的临时选择状态）。 */
    private static final Map<UUID, UUID> PENDING_FIRST = new HashMap<>();

    /**
     * 玩家 UUID -> 上次处理连挂交互的游戏刻，用于去重。
     * UseEntityCallback 对单次右键会触发两次（客户端同时发 INTERACT 与 INTERACT_AT 两个包），
     * 若不去重，一次点击就会先“选中前车”又立刻“连挂自己→取消”。
     */
    private static final Map<UUID, Long> LAST_ACTION_TICK = new HashMap<>();

    public static void register() {
        UseEntityCallback.EVENT.register(CouplingHandler::onUseEntity);
    }

    private static class_1269 onUseEntity(class_1657 player, class_1937 world, class_1268 hand,
                                            class_1297 entity, class_3966 hitResult) {
        // 仅服务端、仅主手、且手持连挂棒、且点到的是矿车时才处理
        if (world.field_9236) return class_1269.field_5811;
        if (hand != class_1268.field_5808) return class_1269.field_5811;
        if (!player.method_5998(hand).method_31574(ModItems.COUPLER)) return class_1269.field_5811;
        if (!(entity instanceof class_1688 cart)) return class_1269.field_5811;

        // 去重：同一玩家在同一游戏刻内只处理一次（回避 UseEntityCallback 的双重触发）
        UUID pid = player.method_5667();
        long now = world.method_8510();
        Long last = LAST_ACTION_TICK.get(pid);
        if (last != null && last == now) {
            return class_1269.field_5812;
        }
        LAST_ACTION_TICK.put(pid, now);

        // 潜行 = 解挂该车厢
        if (player.method_5715()) {
            decouple(cart);
            player.method_7353(class_2561.method_43470("已解除该车厢的连挂").method_27692(class_124.field_1054), true);
            return class_1269.field_5812;
        }

        UUID firstId = PENDING_FIRST.get(pid);

        if (firstId == null) {
            // 第一次点击：记录前车
            PENDING_FIRST.put(pid, cart.method_5667());
            player.method_7353(class_2561.method_43470("已选择前车，请点击要挂在其后的车厢").method_27692(class_124.field_1075), true);
            return class_1269.field_5812;
        }

        PENDING_FIRST.remove(pid);

        if (firstId.equals(cart.method_5667())) {
            player.method_7353(class_2561.method_43470("已取消选择（不能连挂自己）").method_27692(class_124.field_1080), true);
            return class_1269.field_5812;
        }

        // 第二次点击的 cart 挂在 first 之后：cart 跟随 first
        ((AttachmentTarget) cart).setAttached(ModAttachments.FOLLOW_TARGET, firstId);
        player.method_7353(class_2561.method_43470("连挂成功 ✔ 已组成列车组").method_27692(class_124.field_1060), true);
        return class_1269.field_5812;
    }

    private static void decouple(class_1688 cart) {
        ((AttachmentTarget) cart).removeAttached(ModAttachments.FOLLOW_TARGET);
    }

    /**
     * 每 tick 由 Mixin 调用：若本车厢是跟随者，则贴住其前车。
     */
    public static void tickFollower(class_1688 cart) {
        AttachmentTarget target = (AttachmentTarget) cart;
        UUID leaderId = target.getAttached(ModAttachments.FOLLOW_TARGET);
        if (leaderId == null) return; // 不是跟随者，正常自由行驶
        if (!(cart.method_37908() instanceof class_3218 serverWorld)) return;

        class_1297 leaderEntity = serverWorld.method_14190(leaderId);
        if (!(leaderEntity instanceof class_1688 leader) || leader.method_31481()) {
            // 前车暂时不在（可能所在区块未加载）——保持连挂，等它回来。
            // TODO(特性五)：配合列车自带区块加载，避免前车被卸载导致列车分家。
            return;
        }

        // 把前车的巡航速度上限同步给本车厢，保证整列都能突破限速跟上
        Double leaderCruise = ((AttachmentTarget) leader).getAttached(ModAttachments.CRUISE_SPEED);
        if (leaderCruise != null) {
            target.setAttached(ModAttachments.CRUISE_SPEED, leaderCruise);
        } else if (target.hasAttached(ModAttachments.CRUISE_SPEED)) {
            target.removeAttached(ModAttachments.CRUISE_SPEED);
        }

        class_243 delta = leader.method_19538().method_1020(cart.method_19538());
        double dist = delta.method_1033();

        if (dist > MAX_DISTANCE) {
            // 距离过大：判定脱节，安全解挂。
            target.removeAttached(ModAttachments.FOLLOW_TARGET);
            return;
        }

        class_243 desiredVel;
        if (dist < 1.0E-4D) {
            desiredVel = leader.method_18798();
        } else {
            class_243 dir = delta.method_1021(1.0D / dist);
            double correction = class_3532.method_15350((dist - GAP) * STIFFNESS, -MAX_CORRECTION, MAX_CORRECTION);
            // 目标速度 = 前车速度（同步动能）+ 朝前车方向的间距修正（维持固定车距）
            desiredVel = leader.method_18798().method_1019(dir.method_1021(correction));
        }

        cart.method_18799(desiredVel);
        cart.field_6037 = true; // 触发速度同步，客户端观感更平滑
    }
}
