package com.vanillaplus.metro.client;

import com.vanillaplus.metro.command.CommandResultPayload;
import com.vanillaplus.metro.command.OpenEditorPayload;
import com.vanillaplus.metro.registry.ModBlocks;
import com.vanillaplus.metro.registry.ModItems;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.ColorProviderRegistry;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.class_1271;
import net.minecraft.class_1921;
import net.minecraft.class_2741;
import net.minecraft.class_310;

/**
 * 客户端入口：注册「指令平板」的开界面手势与结果接收。
 */
public class VanillaPlusMetroClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        // 右键手持「指令平板」打开控制台界面
        UseItemCallback.EVENT.register((player, world, hand) -> {
            if (world.field_9236 && player.method_5998(hand).method_31574(ModItems.COMMAND_TABLET)) {
                class_310.method_1551().method_1507(new CommandConsoleScreen());
                return class_1271.method_22427(player.method_5998(hand));
            }
            return class_1271.method_22430(player.method_5998(hand));
        });

        // 接收服务端返回的执行结果，刷进界面输出框
        ClientPlayNetworking.registerGlobalReceiver(CommandResultPayload.ID, (payload, context) ->
                context.client().execute(() -> CommandConsoleScreen.setOutput(payload.result())));

        // 接收"打开编程界面"：为指定方块打开绑定的编辑器
        ClientPlayNetworking.registerGlobalReceiver(OpenEditorPayload.ID, (payload, context) ->
                context.client().execute(() ->
                        class_310.method_1551().method_1507(
                                new CommandConsoleScreen(payload.pos(), payload.program(), payload.catalog(), payload.bindings()))));

        // 蓝色红石线：登记到 cutout 渲染层（否则透明处被渲染成黑色方块），并复用灰度模型按强度染蓝
        BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.BLUE_REDSTONE_WIRE, class_1921.method_23581());
        ColorProviderRegistry.BLOCK.register((state, view, pos, tintIndex) -> {
            int power = state.method_11654(class_2741.field_12511);
            int blue = 110 + power * 9;   // 110..245
            int green = 20 + power * 3;
            return (green << 8) | blue;   // 0x00GGBB，红色分量为 0 → 蓝色
        }, ModBlocks.BLUE_REDSTONE_WIRE);

        // 蓝红石物品图标：灰度荧石粉贴图染成蓝色
        ColorProviderRegistry.ITEM.register((stack, tintIndex) -> tintIndex == 0 ? 0x3A6BFF : -1,
                ModItems.BLUE_REDSTONE);
    }
}
