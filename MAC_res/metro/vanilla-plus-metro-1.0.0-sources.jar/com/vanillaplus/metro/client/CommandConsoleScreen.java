package com.vanillaplus.metro.client;

import com.vanillaplus.metro.command.RunCommandsPayload;
import com.vanillaplus.metro.command.SaveProgramPayload;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_124;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_7529;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

/**
 * 多行编辑界面：临时指令控制台 或 方块编程界面。
 * 编程界面：顶部常驻显示已绑定资源；边打边实时提示候选；Tab 补全（引号内补绑定名，引号外补关键字/函数）。
 */
@Environment(EnvType.CLIENT)
public class CommandConsoleScreen extends class_437 {

    private static final int KEY_TAB = 258;

    private static String adhocScript = "# 每行一条指令，# 或 // 开头为注释\nsay hello\ntime set day\n";
    private static String output = "（结果会显示在这里）";
    private static CommandConsoleScreen instance;

    @Nullable
    private final class_2338 boundBlock;
    private final String initialText;
    private final List<String> catalogWords = new ArrayList<>(); // 引号外候选（关键字/函数/资源类型）
    private final List<String> bindingNames = new ArrayList<>();  // 引号内候选（绑定名）
    private String bindingsLine = "";                             // 顶部常驻的已绑定展示

    private class_7529 editor;
    private class_7529 outputBox;
    private String hint = "";

    /** 临时指令控制台。 */
    public CommandConsoleScreen() {
        super(class_2561.method_43470("指令控制台"));
        this.boundBlock = null;
        this.initialText = adhocScript;
    }

    /** 方块编程界面。 */
    public CommandConsoleScreen(class_2338 pos, String program, String catalog, String bindings) {
        super(class_2561.method_43470("编程 · " + pos.method_23854()));
        this.boundBlock = pos;
        this.initialText = program == null ? "" : program;
        if (catalog != null) {
            for (String w : catalog.trim().split("\\s+")) {
                if (isAsciiWord(w)) catalogWords.add(w);
            }
        }
        // bindings：每行 "类型:名字"
        StringBuilder disp = new StringBuilder();
        if (bindings != null && !bindings.isBlank()) {
            for (String line : bindings.split("\n")) {
                int c = line.indexOf(':');
                if (c < 0) continue;
                String kind = line.substring(0, c), name = line.substring(c + 1);
                bindingNames.add(name);
                if (disp.length() > 0) disp.append("  ");
                disp.append(kind.equals("controller") ? "call(\"" + name + "\")" : kind + "[\"" + name + "\"]");
            }
        }
        this.bindingsLine = disp.length() == 0 ? "（本控制器还没绑定任何资源）" : "已绑定：" + disp;
    }

    @Override
    protected void method_25426() {
        instance = this;
        int margin = 16, top = 46, bottom = 46, gap = 12;
        int colW = (this.field_22789 - margin * 2 - gap) / 2;
        int boxH = this.field_22790 - top - bottom;

        editor = new class_7529(this.field_22793, margin, top, colW, boxH,
                class_2561.method_43470("在此输入"), class_2561.method_43470("编辑器"));
        editor.method_44402(30000);
        editor.method_44400(initialText);
        if (boundBlock != null) {
            editor.method_44401(t -> recompute()); // 边打边实时提示
        }
        method_37063(editor);

        outputBox = new class_7529(this.field_22793, margin + colW + gap, top, colW, boxH,
                class_2561.method_43470("输出"), class_2561.method_43470("输出"));
        outputBox.method_44402(31000);
        outputBox.method_44400(output);
        method_37063(outputBox);

        String label = boundBlock != null ? "保存并启用" : "▶ 运行";
        method_37063(class_4185.method_46430(class_2561.method_43470(label), b -> submit())
                .method_46434(this.field_22789 / 2 - 122, this.field_22790 - 26, 120, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("清空"), b -> editor.method_44400(""))
                .method_46434(this.field_22789 / 2 + 2, this.field_22790 - 26, 120, 20).method_46431());
    }

    private void submit() {
        String text = editor.method_44405();
        if (boundBlock != null) {
            ClientPlayNetworking.send(new SaveProgramPayload(boundBlock, text));
        } else {
            adhocScript = text;
            ClientPlayNetworking.send(new RunCommandsPayload(text));
        }
    }

    // ------------------------------------------------------------------
    //  自动补全
    // ------------------------------------------------------------------
    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (keyCode == KEY_TAB && boundBlock != null && editor != null && editor.method_25370()) {
            completeAtCursor();
            return true;
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    /** 边打边算候选，刷新底部提示。 */
    private void recompute() {
        if (editor == null) {
            return;
        }
        Ctx c = context(editor.method_44405());
        if (c.token.isEmpty()) {
            hint = c.quoted ? "输入绑定名…（Tab 补全）" : "";
            return;
        }
        if (c.candidates.isEmpty()) {
            hint = "无候选：" + c.token;
        } else {
            List<String> show = c.candidates.size() > 8 ? c.candidates.subList(0, 8) : c.candidates;
            hint = "候选：" + String.join("  ", show) + (c.candidates.size() > 8 ? " …" : "");
        }
    }

    private void completeAtCursor() {
        String text = editor.method_44405();
        Ctx c = context(text);
        if (c.candidates.isEmpty()) {
            recompute();
            return;
        }
        String common = c.candidates.get(0);
        for (String m : c.candidates) common = commonPrefix(common, m);
        String pick = common.length() > c.token.length() ? common : c.candidates.get(0);
        editor.method_44400(text + pick.substring(c.token.length()));
        recompute();
    }

    /** 当前输入上下文（是否在引号内、当前 token、候选）。假设光标在末尾。 */
    private Ctx context(String text) {
        boolean quoted = count(text, '"') % 2 == 1;
        String token;
        List<String> pool;
        if (quoted) {
            token = text.substring(text.lastIndexOf('"') + 1);
            pool = bindingNames;
        } else {
            int i = text.length();
            while (i > 0 && isWordChar(text.charAt(i - 1))) i--;
            token = text.substring(i);
            pool = catalogWords;
        }
        List<String> cand = new ArrayList<>();
        if (!token.isEmpty()) {
            for (String w : pool) {
                if (w.startsWith(token) && !w.equals(token)) cand.add(w);
            }
        }
        return new Ctx(quoted, token, cand);
    }

    private record Ctx(boolean quoted, String token, List<String> candidates) {}

    private static int count(String s, char ch) {
        int n = 0;
        for (int i = 0; i < s.length(); i++) if (s.charAt(i) == ch) n++;
        return n;
    }
    private static boolean isWordChar(char c) { return Character.isLetterOrDigit(c) || c == '_'; }
    private static boolean isAsciiWord(String s) {
        if (s.isEmpty()) return false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c > 127 || !(Character.isLetterOrDigit(c) || c == '_')) return false;
        }
        return true;
    }
    private static String commonPrefix(String a, String b) {
        int n = Math.min(a.length(), b.length()), i = 0;
        while (i < n && a.charAt(i) == b.charAt(i)) i++;
        return a.substring(0, i);
    }

    public static void setOutput(String text) {
        output = text;
        if (instance != null && instance.outputBox != null) {
            instance.outputBox.method_44400(text);
        }
    }

    @Override
    public void method_25394(class_332 ctx, int mouseX, int mouseY, float delta) {
        super.method_25394(ctx, mouseX, mouseY, delta);
        ctx.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 10, 0xFFFFFF);
        if (boundBlock != null) {
            ctx.method_27535(this.field_22793, class_2561.method_43470("程序（on arrive / if / openDoors() … Tab 补全）").method_27692(class_124.field_1080), 16, 22, 0xFFFFFF);
            String line = this.field_22793.method_27523(bindingsLine, this.field_22789 - 32);
            ctx.method_27535(this.field_22793, class_2561.method_43470(line).method_27692(class_124.field_1075), 16, 33, 0xFFFFFF);
            if (!hint.isEmpty()) {
                ctx.method_27535(this.field_22793, class_2561.method_43470(this.field_22793.method_27523(hint, this.field_22789 - 32)).method_27692(class_124.field_1054), 16, this.field_22790 - 40, 0xFFFFFF);
            }
        }
    }

    @Override
    public void method_25432() {
        if (boundBlock == null && editor != null) {
            adhocScript = editor.method_44405();
        }
        instance = null;
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
