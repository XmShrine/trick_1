package com.vanillaplus.metro.block;

import com.mojang.serialization.MapCodec;
import com.vanillaplus.metro.block.entity.MetroSignalBlockEntity;
import com.vanillaplus.metro.registry.ModBlockEntities;
import net.minecraft.class_124;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2464;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2753;
import net.minecraft.class_3965;
import net.minecraft.class_5558;
import org.jetbrains.annotations.Nullable;

/**
 * 现代信号灯 (Metro Signal)。
 *
 * 放在铁轨旁的装饰性方块，逻辑由方块实体驱动（见 {@link MetroSignalBlockEntity}）：
 *  - LIT=true 绿灯（通行）；LIT=false 红灯（停止），红灯时向外输出 15 级红石信号，可联动原版红石装置。
 *  - FACING 表示其守护/放行的方向。
 */
public class MetroSignalBlock extends class_2237 {

    public static final MapCodec<MetroSignalBlock> CODEC = method_54094(MetroSignalBlock::new);

    public static final class_2753 FACING = class_2741.field_12481;
    public static final class_2746 LIT = class_2741.field_12548; // true=绿灯通行, false=红灯停止

    public MetroSignalBlock(class_2251 settings) {
        super(settings);
        method_9590(method_9595().method_11664()
                .method_11657(FACING, class_2350.field_11043)
                .method_11657(LIT, true));
    }

    @Override
    protected MapCodec<MetroSignalBlock> method_53969() {
        return field_46280;
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING, LIT);
    }

    @Override
    protected class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }

    @Override
    public class_2680 method_9605(class_1750 ctx) {
        // 朝向玩家放置时面朝的方向（= 该信号守护/放行的行车方向）
        return method_9564().method_11657(FACING, ctx.method_8042());
    }

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new MetroSignalBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends class_2586> class_5558<T> method_31645(class_1937 world, class_2680 state,
                                                                  class_2591<T> type) {
        if (world.field_9236) {
            return null;
        }
        return method_31618(type, ModBlockEntities.METRO_SIGNAL, MetroSignalBlockEntity::serverTick);
    }

    // ---- 红灯输出红石信号 ----
    @Override
    protected boolean method_9506(class_2680 state) {
        return true;
    }

    @Override
    protected int method_9524(class_2680 state, class_1922 world, class_2338 pos, class_2350 direction) {
        return state.method_11654(LIT) ? 0 : 15;
    }

    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 world, class_2338 pos,
                                 class_1657 player, class_3965 hit) {
        if (world.field_9236) {
            return class_1269.field_5812;
        }
        if (world.method_8321(pos) instanceof MetroSignalBlockEntity be) {
            class_2561 light = state.method_11654(LIT)
                    ? class_2561.method_43470("🟢 绿灯（通行）").method_27692(class_124.field_1060)
                    : class_2561.method_43470("🔴 红灯（停止）").method_27692(class_124.field_1061);
            class_2338 rail = be.getGuardedRail();
            class_2561 railInfo = rail == null
                    ? class_2561.method_43470(" 未绑定铁轨").method_27692(class_124.field_1080)
                    : class_2561.method_43470(" 守护 " + rail.method_23854()).method_27692(class_124.field_1080);
            player.method_7353(class_2561.method_43470("信号灯：").method_10852(light).method_10852(railInfo), true);
        }
        return class_1269.field_5812;
    }
}
