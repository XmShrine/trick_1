package com.vanillaplus.metro.block;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2457;
import net.minecraft.class_2680;
import net.minecraft.class_2741;

/**
 * 蓝色红石粉：与红色红石粉唯一的区别是**信号强度沿线不衰减**。
 *
 * 实现说明：原版红石靠"每格 -1 的梯度"让断电时能正确归零；去掉衰减后不能再用逐格增量更新
 * （会互相顶着归不了零）。因此改成——每次更新时**泛洪整段连通的蓝红石网络，取其中最大的"外部源"强度，
 * 再把整段统一设为该强度**。外部源计算刻意排除蓝红石自身，避免自反馈。
 */
public class BlueRedstoneWireBlock extends class_2457 {

    /** 单段网络的泛洪上限，防止超大网络卡服。 */
    private static final int MAX_NETWORK = 4096;
    /** 防止 setBlockState 触发的邻居更新递归重入。 */
    private static boolean updating = false;

    public BlueRedstoneWireBlock(class_2251 settings) {
        super(settings);
    }

    @Override
    protected void method_9615(class_2680 state, class_1937 world, class_2338 pos, class_2680 oldState, boolean notify) {
        if (!world.field_9236) {
            updateNetwork(world, pos);
        }
    }

    @Override
    protected void method_9612(class_2680 state, class_1937 world, class_2338 pos, class_2248 sourceBlock, class_2338 sourcePos, boolean notify) {
        if (world.field_9236) {
            return;
        }
        if (!state.method_26184(world, pos)) {
            class_2248.method_9497(state, world, pos);
            world.method_8650(pos, false);
            return;
        }
        updateNetwork(world, pos);
    }

    private void updateNetwork(class_1937 world, class_2338 start) {
        if (updating) {
            return;
        }
        updating = true;
        try {
            // 1) 泛洪收集连通的蓝红石线
            Set<class_2338> net = new HashSet<>();
            Deque<class_2338> queue = new ArrayDeque<>();
            class_2338 s = start.method_10062();
            net.add(s);
            queue.add(s);
            while (!queue.isEmpty() && net.size() <= MAX_NETWORK) {
                class_2338 p = queue.poll();
                for (class_2338 n : wireNeighbors(world, p)) {
                    if (net.add(n)) {
                        queue.add(n);
                    }
                }
            }
            // 2) 求整段网络的最大外部红石源
            int maxSource = 0;
            for (class_2338 p : net) {
                maxSource = Math.max(maxSource, externalPower(world, p));
                if (maxSource >= 15) {
                    break;
                }
            }
            // 3) 全段统一为同一强度（不衰减）
            for (class_2338 p : net) {
                class_2680 bs = world.method_8320(p);
                if (bs.method_27852(this) && bs.method_11654(class_2741.field_12511) != maxSource) {
                    world.method_8652(p, bs.method_11657(class_2741.field_12511, maxSource), class_2248.field_31036);
                }
            }
        } finally {
            updating = false;
        }
    }

    /** 连通邻居：水平 + 上/下坡（同原版红石爬块规则）。 */
    private List<class_2338> wireNeighbors(class_1937 world, class_2338 pos) {
        List<class_2338> out = new ArrayList<>();
        for (class_2350 d : class_2350.class_2353.field_11062) {
            class_2338 flat = pos.method_10093(d);
            addIfWire(world, flat, out);
            addIfWire(world, flat.method_10084(), out);
            addIfWire(world, flat.method_10074(), out);
        }
        return out;
    }

    private void addIfWire(class_1937 world, class_2338 pos, List<class_2338> out) {
        if (world.method_8320(pos).method_27852(this)) {
            out.add(pos.method_10062());
        }
    }

    /** 某处从"非蓝红石邻居"收到的最大红石强度（排除蓝红石自身，避免自反馈）。 */
    private int externalPower(class_1937 world, class_2338 pos) {
        int max = 0;
        for (class_2350 d : class_2350.values()) {
            class_2338 np = pos.method_10093(d);
            if (world.method_8320(np).method_27852(this)) {
                continue;
            }
            max = Math.max(max, world.method_49808(np, d));
            if (max >= 15) {
                break;
            }
        }
        return max;
    }
}
