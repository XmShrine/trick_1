package com.vanillaplus.metro.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2753;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_5819;
import net.minecraft.class_9062;

/**
 * 地铁闸机 (Turnstile)。
 *
 * 1 格高、默认关闭（有碰撞体阻挡通行）：
 *  - 手持车票（绿宝石）右键 → 消耗 1 张 → 开启，若干 tick 后自动关闭。
 *  - 接收到红石信号 → 开启（撤销信号后自动关闭）。
 */
public class TurnstileBlock extends class_2383 {

    public static final MapCodec<TurnstileBlock> CODEC = method_54094(TurnstileBlock::new);

    public static final class_2753 FACING = class_2383.field_11177;
    public static final class_2746 OPEN = class_2741.field_12537;
    public static final class_2746 POWERED = class_2741.field_12484;

    /** 车票物品。 */
    private static final net.minecraft.class_1792 FARE_ITEM = class_1802.field_8687;
    /** 刷卡开启后自动关闭的延迟（tick）。 */
    private static final int AUTO_CLOSE_TICKS = 40;

    // 关门时横跨通道的挡板碰撞体（按朝向轴向选择）
    private static final class_265 SHAPE_X = class_2248.method_9541(6.0, 0.0, 0.0, 10.0, 16.0, 16.0);
    private static final class_265 SHAPE_Z = class_2248.method_9541(0.0, 0.0, 6.0, 16.0, 16.0, 10.0);

    public TurnstileBlock(class_2251 settings) {
        super(settings);
        method_9590(method_9595().method_11664()
                .method_11657(field_11177, class_2350.field_11043)
                .method_11657(OPEN, false)
                .method_11657(POWERED, false));
    }

    @Override
    protected MapCodec<TurnstileBlock> method_53969() {
        return field_46280;
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(field_11177, OPEN, POWERED);
    }

    @Override
    public class_2680 method_9605(net.minecraft.class_1750 ctx) {
        boolean powered = ctx.method_8045().method_49803(ctx.method_8037());
        return method_9564()
                .method_11657(field_11177, ctx.method_8042().method_10153())
                .method_11657(OPEN, powered)
                .method_11657(POWERED, powered);
    }

    private static class_265 shapeFor(class_2680 state) {
        return state.method_11654(field_11177).method_10166() == class_2350.class_2351.field_11048 ? SHAPE_X : SHAPE_Z;
    }

    @Override
    protected class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 ctx) {
        return shapeFor(state);
    }

    @Override
    protected class_265 method_9549(class_2680 state, class_1922 world, class_2338 pos, class_3726 ctx) {
        return state.method_11654(OPEN) ? class_259.method_1073() : shapeFor(state);
    }

    @Override
    protected class_9062 method_55765(class_1799 stack, class_2680 state, class_1937 world, class_2338 pos,
                                             class_1657 player, class_1268 hand, class_3965 hit) {
        if (state.method_11654(OPEN)) {
            return class_9062.field_47731;
        }
        if (!stack.method_31574(FARE_ITEM)) {
            if (!world.field_9236) {
                player.method_7353(net.minecraft.class_2561.method_43470("需要车票（绿宝石）才能通过闸机")
                        .method_27692(net.minecraft.class_124.field_1061), true);
            }
            return class_9062.field_47729; // 拦截，避免误放置绿宝石以外的方块
        }
        if (!world.field_9236) {
            if (!player.method_7337()) {
                stack.method_7934(1);
            }
            openGate(state, world, pos);
            player.method_7353(net.minecraft.class_2561.method_43470("已刷卡，请通过")
                    .method_27692(net.minecraft.class_124.field_1060), true);
        }
        return class_9062.field_47728;
    }

    private void openGate(class_2680 state, class_1937 world, class_2338 pos) {
        world.method_8652(pos, state.method_11657(OPEN, true), class_2248.field_31036);
        world.method_8396(null, pos, class_3417.field_14567, class_3419.field_15245, 1.0F, 1.2F);
        world.method_39279(pos, this, AUTO_CLOSE_TICKS);
    }

    @Override
    protected void method_9588(class_2680 state, class_3218 world, class_2338 pos, class_5819 random) {
        // 自动关门：仅在没有红石信号维持时关闭
        if (state.method_11654(OPEN) && !state.method_11654(POWERED)) {
            world.method_8652(pos, state.method_11657(OPEN, false), class_2248.field_31036);
            world.method_8396(null, pos, class_3417.field_14819, class_3419.field_15245, 1.0F, 1.0F);
        }
    }

    @Override
    protected void method_9612(class_2680 state, class_1937 world, class_2338 pos, class_2248 sourceBlock,
                                  class_2338 sourcePos, boolean notify) {
        if (world.field_9236) {
            return;
        }
        boolean powered = world.method_49803(pos);
        if (powered != state.method_11654(POWERED)) {
            class_2680 newState = state.method_11657(POWERED, powered).method_11657(OPEN, powered || state.method_11654(OPEN));
            world.method_8652(pos, newState, class_2248.field_31028);
            if (powered) {
                world.method_8396(null, pos, class_3417.field_14567, class_3419.field_15245, 1.0F, 1.2F);
            } else {
                // 红石撤销后，安排一次关门检查
                world.method_39279(pos, this, AUTO_CLOSE_TICKS);
            }
        }
    }
}
