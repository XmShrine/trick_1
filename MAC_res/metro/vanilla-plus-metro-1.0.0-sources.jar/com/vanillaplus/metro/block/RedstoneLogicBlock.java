package com.vanillaplus.metro.block;

import com.mojang.serialization.MapCodec;
import com.vanillaplus.metro.block.entity.RedstoneLogicBlockEntity;
import com.vanillaplus.metro.registry.ModBlockEntities;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2464;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2753;
import net.minecraft.class_3965;
import net.minecraft.class_5558;
import org.jetbrains.annotations.Nullable;

/**
 * 5 出 1 入 可编程红石块。FACING 面 = 输入面（纹理不同），其余 5 面为输出。
 * 空手右键旋转朝向（换输入面）；手持指令平板右键 = 编程界面。
 */
public class RedstoneLogicBlock extends class_2237 {

    public static final MapCodec<RedstoneLogicBlock> CODEC = method_54094(RedstoneLogicBlock::new);
    public static final class_2753 FACING = class_2741.field_12525;

    public RedstoneLogicBlock(class_2251 settings) {
        super(settings);
        method_9590(method_9595().method_11664().method_11657(FACING, class_2350.field_11043));
    }

    @Override protected MapCodec<RedstoneLogicBlock> method_53969() { return field_46280; }
    @Override protected void method_9515(class_2689.class_2690<class_2248, class_2680> b) { b.method_11667(FACING); }
    @Override protected class_2464 method_9604(class_2680 state) { return class_2464.field_11458; }

    @Override
    public class_2680 method_9605(class_1750 ctx) {
        // 输入面朝向玩家（放置时你看到的那面是输入面）
        return method_9564().method_11657(FACING, ctx.method_7715().method_10153());
    }

    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_3965 hit) {
        if (!world.field_9236) {
            class_2350 next = class_2350.values()[(state.method_11654(FACING).ordinal() + 1) % 6];
            world.method_8652(pos, state.method_11657(FACING, next), class_2248.field_31036);
            player.method_7353(class_2561.method_43470("输入面：" + next.method_15434()), true);
        }
        return class_1269.field_5812;
    }

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new RedstoneLogicBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends class_2586> class_5558<T> method_31645(class_1937 world, class_2680 state, class_2591<T> type) {
        if (world.field_9236) {
            return null;
        }
        return method_31618(type, ModBlockEntities.REDSTONE_LOGIC, RedstoneLogicBlockEntity::serverTick);
    }

    // ---- 红石输出：每个输出面发出其设定强度；输入面不发出 ----
    @Override
    protected boolean method_9506(class_2680 state) {
        return true;
    }

    @Override
    protected int method_9524(class_2680 state, class_1922 view, class_2338 pos, class_2350 direction) {
        class_2350 face = direction.method_10153();
        if (face == state.method_11654(FACING)) {
            return 0; // 输入面
        }
        return view.method_8321(pos) instanceof RedstoneLogicBlockEntity be ? be.getOutput(face) : 0;
    }

    @Override
    protected int method_9603(class_2680 state, class_1922 view, class_2338 pos, class_2350 direction) {
        return method_9524(state, view, pos, direction);
    }
}
