package com.vanillaplus.metro.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_1309;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2753;
import net.minecraft.class_2754;
import net.minecraft.class_2756;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3726;
import org.jetbrains.annotations.Nullable;

/**
 * 现代屏蔽门 (Platform Screen Door)。
 *
 * 2 格高的自定义方块（框架玻璃面板，风格与地铁闸机统一，不再沿用原版铁门外观）：
 *  - 平时关闭，具备碰撞体挡人；开启时无碰撞可通行。
 *  - 玩家无法徒手开关，只受系统（站台核心块）或红石控制。
 *  - 列车停稳自动开门，发车前 3 秒自动关门（由站台核心块驱动）。
 */
public class ScreenDoorBlock extends class_2248 {

    public static final MapCodec<ScreenDoorBlock> field_46280 = method_54094(ScreenDoorBlock::new);

    public static final class_2753 FACING = class_2741.field_12481;
    public static final class_2746 OPEN = class_2741.field_12537;
    public static final class_2746 POWERED = class_2741.field_12484;
    public static final class_2754<class_2756> HALF = class_2741.field_12533;

    private static final class_265 SHAPE_X = class_2248.method_9541(6.0, 0.0, 0.0, 10.0, 16.0, 16.0);
    private static final class_265 SHAPE_Z = class_2248.method_9541(0.0, 0.0, 6.0, 16.0, 16.0, 10.0);

    public ScreenDoorBlock(class_2251 settings) {
        super(settings);
        method_9590(method_9595().method_11664()
                .method_11657(FACING, class_2350.field_11043)
                .method_11657(OPEN, false)
                .method_11657(POWERED, false)
                .method_11657(HALF, class_2756.field_12607));
    }

    @Override
    protected MapCodec<ScreenDoorBlock> method_53969() {
        return field_46280;
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING, OPEN, POWERED, HALF);
    }

    private static class_265 shapeFor(class_2680 state) {
        return state.method_11654(FACING).method_10166() == class_2350.class_2351.field_11048 ? SHAPE_X : SHAPE_Z;
    }

    @Override
    protected class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 ctx) {
        return state.method_11654(OPEN) ? class_259.method_1073() : shapeFor(state);
    }

    @Override
    protected class_265 method_9549(class_2680 state, class_1922 world, class_2338 pos, class_3726 ctx) {
        return state.method_11654(OPEN) ? class_259.method_1073() : shapeFor(state);
    }

    // ---- 2 格高的放置与破坏 ----
    @Nullable
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        class_1937 world = ctx.method_8045();
        class_2338 pos = ctx.method_8037();
        if (pos.method_10264() < world.method_31600() - 1 && world.method_8320(pos.method_10084()).method_26166(ctx)) {
            boolean powered = world.method_49803(pos) || world.method_49803(pos.method_10084());
            return method_9564()
                    .method_11657(FACING, ctx.method_8042())
                    .method_11657(HALF, class_2756.field_12607)
                    .method_11657(OPEN, powered)
                    .method_11657(POWERED, powered);
        }
        return null;
    }

    @Override
    public void method_9567(class_1937 world, class_2338 pos, class_2680 state, @Nullable class_1309 placer, class_1799 stack) {
        world.method_8652(pos.method_10084(), state.method_11657(HALF, class_2756.field_12609), class_2248.field_31036);
    }

    @Override
    protected class_2680 method_9559(class_2680 state, class_2350 direction, class_2680 neighborState,
                                                   class_1936 world, class_2338 pos, class_2338 neighborPos) {
        class_2756 half = state.method_11654(HALF);
        // 当“应当是另一半”的相邻方块消失时，本半格也变为空气（破坏一半即两半齐破）
        if (direction.method_10166() == class_2350.class_2351.field_11052
                && (half == class_2756.field_12607) == (direction == class_2350.field_11036)) {
            return neighborState.method_27852(this) && neighborState.method_11654(HALF) != half
                    ? state
                    : class_2246.field_10124.method_9564();
        }
        return super.method_9559(state, direction, neighborState, world, pos, neighborPos);
    }

    @Override
    protected void method_9612(class_2680 state, class_1937 world, class_2338 pos, class_2248 sourceBlock,
                                  class_2338 sourcePos, boolean notify) {
        if (world.field_9236) {
            return;
        }
        class_2338 other = state.method_11654(HALF) == class_2756.field_12607 ? pos.method_10084() : pos.method_10074();
        boolean powered = world.method_49803(pos) || world.method_49803(other);
        if (powered != state.method_11654(POWERED)) {
            world.method_8652(pos, state.method_11657(POWERED, powered).method_11657(OPEN, powered), class_2248.field_31028);
            if (state.method_11654(HALF) == class_2756.field_12607) {
                world.method_8396(null, pos,
                        powered ? class_3417.field_14567 : class_3417.field_14819,
                        class_3419.field_15245, 1.0F, 1.0F);
            }
        }
    }

    /** 供站台核心块调用：开/关某处的屏蔽门（同时作用于上下两格）。 */
    public static void setOpen(class_1937 world, class_2338 anyHalf, boolean open) {
        class_2680 s = world.method_8320(anyHalf);
        if (!(s.method_26204() instanceof ScreenDoorBlock)) {
            return;
        }
        class_2338 lower = s.method_11654(HALF) == class_2756.field_12607 ? anyHalf : anyHalf.method_10074();
        class_2680 lowerState = world.method_8320(lower);
        class_2680 upperState = world.method_8320(lower.method_10084());
        if (!(lowerState.method_26204() instanceof ScreenDoorBlock) || lowerState.method_11654(OPEN) == open) {
            return;
        }
        world.method_8652(lower, lowerState.method_11657(OPEN, open), class_2248.field_31036);
        if (upperState.method_26204() instanceof ScreenDoorBlock) {
            world.method_8652(lower.method_10084(), upperState.method_11657(OPEN, open), class_2248.field_31036);
        }
        world.method_8396(null, lower,
                open ? class_3417.field_14567 : class_3417.field_14819,
                class_3419.field_15245, 1.0F, 1.0F);
    }
}
