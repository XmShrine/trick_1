package com.vanillaplus.metro.block;

import com.mojang.serialization.MapCodec;
import com.vanillaplus.metro.block.entity.LineControlPanelBlockEntity;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2338;
import net.minecraft.class_2464;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import org.jetbrains.annotations.Nullable;

/**
 * 线路总控面板 (Line Control Panel)。
 *
 * 统筹整条地铁线路的寻路检测与调度（特性四）：
 *  - 记录起点/终点站台，BFS 沿铁轨拓扑检测线路是否连通。
 *  - 注册多条线路并调度多组连挂矿车循环运行。
 *
 * 本轮先落地方块与方块实体骨架；寻路/调度逻辑在特性四实现。
 */
public class LineControlPanelBlock extends class_2237 {

    public static final MapCodec<LineControlPanelBlock> CODEC = method_54094(LineControlPanelBlock::new);

    public LineControlPanelBlock(class_2251 settings) {
        super(settings);
    }

    @Override
    protected MapCodec<LineControlPanelBlock> method_53969() {
        return field_46280;
    }

    @Override
    protected class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new LineControlPanelBlockEntity(pos, state);
    }

    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 world, class_2338 pos,
                                 class_1657 player, class_3965 hit) {
        if (world.field_9236) {
            return class_1269.field_5812;
        }
        if (world.method_8321(pos) instanceof LineControlPanelBlockEntity be
                && world instanceof net.minecraft.class_3218 sw) {
            // 右键即沿铁轨 BFS 检测线路连通性并统计站点
            player.method_7353(be.runScan(sw, pos), false);
        }
        return class_1269.field_5812;
    }
}
