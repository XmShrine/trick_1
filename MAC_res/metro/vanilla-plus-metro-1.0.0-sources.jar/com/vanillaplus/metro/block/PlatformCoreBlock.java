package com.vanillaplus.metro.block;

import com.mojang.serialization.MapCodec;
import com.vanillaplus.metro.block.entity.PlatformCoreBlockEntity;
import com.vanillaplus.metro.registry.ModBlockEntities;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2343;
import net.minecraft.class_2464;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import net.minecraft.class_5558;
import org.jetbrains.annotations.Nullable;

/**
 * 站台核心块 (Platform Core)。
 *
 * 铺设在铁轨正下方，作为一座站台的控制中枢：
 *  - 存储该站台对通过列车的控制参数（停车时间 / 启动加速度 / 巡航速度），数据保存在方块实体 NBT。
 *  - 右键调整参数（空手右键 = 增大当前参数；潜行右键 = 切换当前参数），实时以动作栏反馈。
 *  - 通过方块实体的服务端 tick 检测上方列车并执行停靠/发车逻辑（在特性三中实现）。
 */
public class PlatformCoreBlock extends class_2237 implements class_2343 {

    public static final MapCodec<PlatformCoreBlock> CODEC = method_54094(PlatformCoreBlock::new);

    public PlatformCoreBlock(class_2251 settings) {
        super(settings);
    }

    @Override
    protected MapCodec<PlatformCoreBlock> method_53969() {
        return field_46280;
    }

    @Override
    protected class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458; // 带方块实体的方块默认不渲染，这里恢复为普通模型渲染
    }

    @Nullable
    @Override
    public class_2586 method_10123(net.minecraft.class_2338 pos, class_2680 state) {
        return new PlatformCoreBlockEntity(pos, state);
    }

    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 world, net.minecraft.class_2338 pos,
                                 class_1657 player, class_3965 hit) {
        if (world.field_9236) {
            return class_1269.field_5812;
        }
        if (world.method_8321(pos) instanceof PlatformCoreBlockEntity be) {
            if (player.method_5715()) {
                be.cycleSelectedParam();
            } else {
                be.stepSelectedParam();
            }
            player.method_7353(be.describeConfig(), true);
            be.method_5431();
        }
        return class_1269.field_5812;
    }

    @Nullable
    @Override
    public <T extends class_2586> class_5558<T> method_31645(class_1937 world, class_2680 state,
                                                                  class_2591<T> type) {
        if (world.field_9236) {
            return null;
        }
        // 特性三：由方块实体的服务端 tick 驱动列车停靠/发车控制
        return method_31618(type, ModBlockEntities.PLATFORM_CORE, PlatformCoreBlockEntity::serverTick);
    }
}
