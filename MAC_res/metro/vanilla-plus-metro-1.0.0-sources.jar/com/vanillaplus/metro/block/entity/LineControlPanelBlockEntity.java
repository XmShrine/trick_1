package com.vanillaplus.metro.block.entity;

import com.vanillaplus.metro.metro.RailPathfinder;
import com.vanillaplus.metro.registry.ModBlockEntities;
import com.vanillaplus.metro.registry.ModBlocks;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_7225;

/**
 * 线路总控面板的方块实体（特性四 + 信号系统）。
 *
 * 右键面板即沿铁轨做 BFS 拓扑检测：从面板附近的铁轨出发遍历整个连通网络，
 * 统计站台数与轨道段数，判定线路是否连通，并将结果持久化。
 * 同时维护本线路注册的「现代信号灯」列表（由信号配置器绑定）。
 *
 * 说明：多组连挂矿车的自动调度（循环往复）依赖站台核心块已实现的停靠/发车控制，
 * 面板负责“连通检测 + 线路信息 + 信号灯登记”；完整的多车编组调度留待后续扩展。
 */
public class LineControlPanelBlockEntity extends class_2586 {

    private static final int RAIL_SEARCH_RADIUS = 3;

    private String lineName = "1 号线";
    private boolean connected = false;
    private int stationCount = 0;
    private int railCount = 0;
    /** 本线路注册的信号灯位置（打包 long）。 */
    private final List<Long> boundSignals = new ArrayList<>();

    public LineControlPanelBlockEntity(class_2338 pos, class_2680 state) {
        super(ModBlockEntities.LINE_CONTROL_PANEL, pos, state);
    }

    /** 右键触发：沿铁轨 BFS 检测线路连通性并统计站点。返回给玩家的反馈文本。 */
    public class_2561 runScan(class_3218 world, class_2338 panelPos) {
        class_2338 startRail = RailPathfinder.findNearbyRail(world, panelPos, RAIL_SEARCH_RADIUS);
        if (startRail == null) {
            connected = false;
            stationCount = 0;
            railCount = 0;
            method_5431();
            return class_2561.method_43470("[" + lineName + "] 附近 " + RAIL_SEARCH_RADIUS + " 格内未找到铁轨，请贴近线路放置")
                    .method_27692(class_124.field_1061);
        }

        RailPathfinder.NetworkScan scan = RailPathfinder.scan(
                world, startRail, RailPathfinder.DEFAULT_MAX_RAILS,
                (w, railPos) -> w.method_8320(railPos.method_10074()).method_27852(ModBlocks.PLATFORM_CORE));

        railCount = scan.rails().size();
        stationCount = scan.stations().size();
        connected = stationCount >= 2 && !scan.capped();
        method_5431();

        if (scan.capped()) {
            return class_2561.method_43470("[" + lineName + "] ")
                    .method_10852(class_2561.method_43470("【线路过长/可能中断】").method_27692(class_124.field_1061))
                    .method_10852(class_2561.method_43470("已扫描 " + railCount + " 段轨道达到上限").method_27692(class_124.field_1080));
        }
        if (stationCount < 2) {
            return class_2561.method_43470("[" + lineName + "] ")
                    .method_10852(class_2561.method_43470("【线路未成线】").method_27692(class_124.field_1054))
                    .method_10852(class_2561.method_43470("仅发现 " + stationCount + " 座站台（需 ≥2）；共 " + railCount + " 段轨道")
                            .method_27692(class_124.field_1080));
        }
        return class_2561.method_43470("[" + lineName + "] ")
                .method_10852(class_2561.method_43470("【线路已连通】").method_27692(class_124.field_1060))
                .method_10852(class_2561.method_43470(stationCount + " 座站台，" + railCount + " 段轨道").method_27692(class_124.field_1075));
    }

    /** 由信号配置器调用：把一盏信号灯注册到本线路。 */
    public void bindSignal(class_2338 signalPos) {
        long key = signalPos.method_10063();
        if (!boundSignals.contains(key)) {
            boundSignals.add(key);
            method_5431();
        }
    }

    public int getBoundSignalCount() {
        return boundSignals.size();
    }

    public class_2561 describeStatus() {
        class_2561 stateText = connected
                ? class_2561.method_43470("【线路已连通】").method_27692(class_124.field_1060)
                : class_2561.method_43470("【未检测/未连通】").method_27692(class_124.field_1061);
        return class_2561.method_43470("[" + lineName + "] ").method_27692(class_124.field_1075).method_10852(stateText)
                .method_10852(class_2561.method_43470("  " + stationCount + " 站 / " + railCount + " 轨 / "
                        + boundSignals.size() + " 信号").method_27692(class_124.field_1080));
    }

    @Override
    protected void method_11007(class_2487 nbt, class_7225.class_7874 registries) {
        super.method_11007(nbt, registries);
        nbt.method_10582("LineName", lineName);
        nbt.method_10556("Connected", connected);
        nbt.method_10569("StationCount", stationCount);
        nbt.method_10569("RailCount", railCount);
        nbt.method_10564("BoundSignals", boundSignals.stream().mapToLong(Long::longValue).toArray());
    }

    @Override
    protected void method_11014(class_2487 nbt, class_7225.class_7874 registries) {
        super.method_11014(nbt, registries);
        if (nbt.method_10545("LineName")) {
            lineName = nbt.method_10558("LineName");
        }
        connected = nbt.method_10577("Connected");
        stationCount = nbt.method_10550("StationCount");
        railCount = nbt.method_10550("RailCount");
        boundSignals.clear();
        for (long l : nbt.method_10565("BoundSignals")) {
            boundSignals.add(l);
        }
    }
}
