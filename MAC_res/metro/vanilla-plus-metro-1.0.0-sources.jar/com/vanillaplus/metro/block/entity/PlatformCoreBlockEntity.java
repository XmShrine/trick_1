package com.vanillaplus.metro.block.entity;

import com.vanillaplus.metro.VanillaPlusMetro;
import com.vanillaplus.metro.block.ScreenDoorBlock;
import com.vanillaplus.metro.metro.CruiseController;
import com.vanillaplus.metro.program.Actuators;
import com.vanillaplus.metro.program.CallGuard;
import com.vanillaplus.metro.program.MetroScript;
import com.vanillaplus.metro.program.ProgramContext;
import com.vanillaplus.metro.program.ProgrammableController;
import com.vanillaplus.metro.program.ScriptException;
import com.vanillaplus.metro.registry.ModAttachments;
import com.vanillaplus.metro.registry.ModBlockEntities;
import com.vanillaplus.metro.registry.ModBlocks;
import net.fabricmc.fabric.api.attachment.v1.AttachmentTarget;
import net.minecraft.class_124;
import net.minecraft.class_1297;
import net.minecraft.class_1688;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2756;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_7225;
import net.minecraft.class_7923;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * 站台核心块的方块实体：保存站台参数（NBT 持久化），并驱动停靠/发车控制。
 *
 * 参数（对应需求文档特性三）：
 *  - stopSeconds  停车时间（秒）。0 = 不停靠直接通过。
 *  - acceleration 启动加速度（格/tick²）。
 *  - cruiseSpeed  巡航速度（m/s，可突破原版 8m/s 限制）。
 *
 * 停靠控制是一个状态机：IDLE → ARRIVING（平滑减速对齐中心）→ DWELLING（开门停靠计时，发车前3秒关门提示）
 * → DEPARTING（按加速度平滑加速至巡航速度驶离）→ IDLE。只对“列车头”（无跟随目标的车厢）生效，
 * 后续车厢由连挂逻辑自动跟随。
 */
public class PlatformCoreBlockEntity extends class_2586 implements ProgrammableController {

    private static final int PHASE_IDLE = 0;
    private static final int PHASE_ARRIVING = 1;
    private static final int PHASE_DWELLING = 2;
    private static final int PHASE_DEPARTING = 3;

    /** 发车前多少 tick 关门并提示（3 秒）。 */
    private static final int WARN_TICKS = 60;
    /** 服务完成后的冷却，避免刚发出的车被立刻再次判定进站。 */
    private static final int COOLDOWN_TICKS = 30;
    /** 对齐中心的判定阈值。 */
    private static final double ALIGN_DIST = 0.16D;
    private static final int DOOR_SCAN_RADIUS = 3;

    // ---- 可配置参数 ----
    private int stopSeconds = 15;
    private double acceleration = 0.02D;
    private double cruiseSpeed = 16.0D;
    /** 折返站：列车停靠完毕后原路反向驶离（无需环形轨道）。 */
    private boolean turnback = false;
    private int selectedParam = 0;

    // ---- 可编程逻辑（可开关；编程模式下 arrive/depart/tick 事件跑用户脚本）----
    private String program = "";
    private boolean programMode = false;
    private transient MetroScript compiled = null;
    private transient String programError = null;

    /** 命名绑定表：名字 → (资源类型, 坐标)。由「绑定工具」写入，供 door["名"] 解析。 */
    public record Binding(String kind, class_2338 pos) {}
    private final Map<String, Binding> bindings = new HashMap<>();

    // ---- 运行期状态 ----
    private int phase = PHASE_IDLE;
    private long servedMost = 0L;
    private long servedLeast = 0L;
    private int dwellTicksLeft = 0;
    private int departTicks = 0;
    private int cooldown = 0;
    private double dirX = 0.0D;
    private double dirZ = 0.0D;

    public PlatformCoreBlockEntity(class_2338 pos, class_2680 state) {
        super(ModBlockEntities.PLATFORM_CORE, pos, state);
    }

    // ------------------------------------------------------------------
    // 参数读写 / 配置交互
    // ------------------------------------------------------------------
    public int getStopSeconds() { return stopSeconds; }
    public int getStopTicks() { return stopSeconds * 20; }
    public double getAcceleration() { return acceleration; }
    public double getCruiseSpeed() { return cruiseSpeed; }
    /** 巡航速度换算为“格/tick”（1 m/s = 0.05 格/tick）。 */
    public double getCruiseSpeedPerTick() { return cruiseSpeed * 0.05D; }

    public boolean isTurnback() { return turnback; }

    public void cycleSelectedParam() {
        selectedParam = (selectedParam + 1) % 4;
    }

    public void stepSelectedParam() {
        switch (selectedParam) {
            case 0 -> stopSeconds = stopSeconds >= 60 ? 0 : stopSeconds + 5;
            case 1 -> {
                double v = Math.round((acceleration + 0.01D) * 100.0D) / 100.0D;
                acceleration = v > 0.10D + 1.0E-6D ? 0.01D : v;
            }
            case 2 -> cruiseSpeed = cruiseSpeed >= 24.0D ? 8.0D : cruiseSpeed + 4.0D;
            case 3 -> turnback = !turnback;
            default -> { }
        }
    }

    public class_2561 describeConfig() {
        return class_2561.method_43470("站台参数 ")
                .method_10852(mark(0, String.format("停车 %ds", stopSeconds)))
                .method_10852(class_2561.method_43470(" | "))
                .method_10852(mark(1, String.format("加速 %.2f", acceleration)))
                .method_10852(class_2561.method_43470(" | "))
                .method_10852(mark(2, String.format("巡航 %.0fm/s", cruiseSpeed)))
                .method_10852(class_2561.method_43470(" | "))
                .method_10852(mark(3, "折返" + (turnback ? "开" : "关")));
    }

    private class_2561 mark(int idx, String s) {
        boolean sel = idx == selectedParam;
        return class_2561.method_43470((sel ? "▶" : "") + s).method_27692(sel ? class_124.field_1054 : class_124.field_1080);
    }

    // ------------------------------------------------------------------
    // 可编程逻辑
    // ------------------------------------------------------------------
    public String getProgram() { return program; }
    public boolean isProgramMode() { return programMode; }
    public void setProgramMode(boolean mode) { this.programMode = mode; method_5431(); }

    /** 由「绑定工具」调用：把一个资源以某名字绑到本核心块。 */
    public void addBinding(String name, String kind, class_2338 p) {
        bindings.put(name, new Binding(kind, p.method_10062()));
        method_5431();
    }
    public java.util.Set<String> bindingNames() { return bindings.keySet(); }

    /** 设置程序并编译；返回语法错误信息（null=成功）。 */
    public String setProgram(String source) {
        this.program = source == null ? "" : source;
        compile();
        method_5431();
        return programError;
    }

    private void compile() {
        programError = null;
        compiled = null;
        if (program == null || program.isBlank()) {
            return;
        }
        try {
            compiled = MetroScript.parse(program);
        } catch (ScriptException e) {
            programError = e.getMessage();
        }
    }

    private void fireEvent(String event, class_3218 world) {
        if (compiled == null) {
            return;
        }
        try {
            compiled.run(event, new ScriptCtx(world));
        } catch (ScriptException e) {
            VanillaPlusMetro.LOGGER.warn("[核心块程序 {}] 事件 {} 出错：{}", field_11867.method_23854(), event, e.getMessage());
        }
    }

    @Override
    public void runEvent(String event) {
        if (method_10997() instanceof class_3218 sw) {
            fireEvent(event, sw);
        }
    }

    @Override
    public java.util.List<String> apiCatalog() {
        java.util.List<String> l = new java.util.ArrayList<>(java.util.List.of(
                "arrive", "depart", "tick", "has", "occupied", "input", "time",
                "openDoors", "closeDoors", "setCruise", "setStop", "log", "call",
                "door", "signal", "switch"));
        l.addAll(bindings.keySet());
        return l;
    }

    @Override
    public String bindingsInfo() {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, Binding> e : bindings.entrySet()) {
            if (sb.length() > 0) sb.append('\n');
            sb.append(e.getValue().kind()).append(':').append(e.getKey());
        }
        return sb.toString();
    }

    /** DSL 与本站台核心块的对接（函数式 API；命名资源绑定后续再加）。 */
    private final class ScriptCtx implements ProgramContext {
        private final class_3218 world;
        ScriptCtx(class_3218 world) { this.world = world; }

        @Override
        public void action(String kind, String name, String method) throws ScriptException {
            if (!kind.equals("door")) {
                throw new ScriptException(0, "未知资源类型 " + kind + "（当前可用：door 或函数）");
            }
            boolean open = method.equals("open");
            Binding b = bindings.get(name);
            if (b != null && b.kind().equals("door")) {
                ScreenDoorBlock.setOpen(world, b.pos(), open); // 绑定名 → 具体那扇门
            } else {
                setDoorsOpen(world, field_11867, open); // 未绑定 → 附近所有门（兼容 openDoors）
            }
        }

        @Override
        public void assign(String kind, String name, Object value) throws ScriptException {
            Binding b = bindings.get(name);
            if (b == null) {
                throw new ScriptException(0, "未绑定的资源 " + kind + "[\"" + name + "\"]（先用绑定工具绑定）");
            }
            if (kind.equals("signal") && b.kind().equals("signal")) {
                Actuators.setSignal(world, b.pos(), String.valueOf(value));
            } else if (kind.equals("switch") && b.kind().equals("switch")) {
                Actuators.setSwitch(world, b.pos(), String.valueOf(value));
            } else {
                throw new ScriptException(0, "不支持写入 " + kind + "[\"" + name + "\"]（类型不符或不支持）");
            }
        }

        @Override
        public Object query(String kind, String name, String prop) throws ScriptException {
            if (kind.equals("door") && prop.equals("open")) {
                Binding b = bindings.get(name);
                if (b != null && b.kind().equals("door")) {
                    class_2680 s = world.method_8320(b.pos());
                    if (s.method_27852(ModBlocks.SCREEN_DOOR)) {
                        return s.method_11654(class_2741.field_12537);
                    }
                }
                return anyDoorOpen(world);
            }
            throw new ScriptException(0, "暂不支持查询 " + kind + "[..]." + prop);
        }

        @Override
        public Object function(String fn, Object[] a) throws ScriptException {
            switch (fn) {
                case "has": {
                    class_2338 p = field_11867.method_10069((int) num(a, 0), (int) num(a, 1), (int) num(a, 2));
                    return blockIdOf(world.method_8320(p).method_26204()).equals(normalizeId(str(a, 3)));
                }
                case "occupied": return platformOccupied(world);
                case "input": return (long) world.method_49804(field_11867);
                case "time": return world.method_8532() % 24000L;
                case "openDoors": setDoorsOpen(world, field_11867, true); return null;
                case "closeDoors": setDoorsOpen(world, field_11867, false); return null;
                case "setCruise": cruiseSpeed = class_3532.method_15350(num(a, 0), 4, 40); method_5431(); return null;
                case "setStop": stopSeconds = (int) class_3532.method_15350(num(a, 0), 0, 60); method_5431(); return null;
                case "log": VanillaPlusMetro.LOGGER.info("[核心块程序 {}] {}", field_11867.method_23854(), str(a, 0)); return null;
                case "call": {
                    Binding b = bindings.get(str(a, 0));
                    if (b == null || !b.kind().equals("controller")) {
                        throw new ScriptException(0, "未绑定控制器 \"" + str(a, 0) + "\"");
                    }
                    if (world.method_8321(b.pos()) instanceof ProgrammableController target) {
                        CallGuard.fire(target, str(a, 1));
                    }
                    return null;
                }
                default: throw new ScriptException(0, "未知函数 " + fn + "()");
            }
        }

        private double num(Object[] a, int i) throws ScriptException {
            if (i >= a.length || !(a[i] instanceof Number n)) throw new ScriptException(0, "参数 " + (i + 1) + " 需要数字");
            return n.doubleValue();
        }
        private String str(Object[] a, int i) { return i < a.length ? String.valueOf(a[i]) : ""; }
    }

    private static String blockIdOf(net.minecraft.class_2248 block) {
        return class_7923.field_41175.method_10221(block).toString();
    }
    private static String normalizeId(String id) {
        return id.contains(":") ? id : "minecraft:" + id;
    }
    private boolean anyDoorOpen(class_3218 world) {
        class_2338.class_2339 p = new class_2338.class_2339();
        for (int dx = -DOOR_SCAN_RADIUS; dx <= DOOR_SCAN_RADIUS; dx++) {
            for (int dz = -DOOR_SCAN_RADIUS; dz <= DOOR_SCAN_RADIUS; dz++) {
                for (int dy = 0; dy <= 2; dy++) {
                    p.method_10103(field_11867.method_10263() + dx, field_11867.method_10264() + dy, field_11867.method_10260() + dz);
                    class_2680 s = world.method_8320(p);
                    if (s.method_27852(ModBlocks.SCREEN_DOOR) && s.method_11654(class_2741.field_12537)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
    private boolean platformOccupied(class_3218 world) {
        return findHeadAbove(world, field_11867.method_10084()) != null
                || !world.method_8390(class_1688.class, new class_238(field_11867.method_10084()).method_1009(0.4, 0.6, 0.4), c -> true).isEmpty();
    }

    // ------------------------------------------------------------------
    // 服务端 tick —— 停靠/发车控制状态机
    // ------------------------------------------------------------------
    public static void serverTick(class_1937 world, class_2338 pos, class_2680 state, PlatformCoreBlockEntity be) {
        if (!(world instanceof class_3218 sw)) {
            return;
        }
        if (be.cooldown > 0) {
            be.cooldown--;
        }
        // 编程模式：on tick(N) 定时事件（节流）
        if (be.programMode && be.compiled != null) {
            int iv = be.compiled.tickInterval();
            if (iv > 0 && sw.method_8510() % iv == 0) {
                be.fireEvent("tick", sw);
            }
        }
        class_2338 railPos = pos.method_10084();

        switch (be.phase) {
            case PHASE_IDLE -> {
                if (be.stopSeconds <= 0 || be.cooldown > 0) {
                    return; // 不停靠站或处于冷却：放行
                }
                class_1688 head = be.findHeadAbove(sw, railPos);
                if (head != null && horizontalSpeed(head) > 0.02D) {
                    class_243 v = head.method_18798();
                    double hs = Math.hypot(v.field_1352, v.field_1350);
                    if (hs > 1.0E-4D) {
                        be.dirX = v.field_1352 / hs;
                        be.dirZ = v.field_1350 / hs;
                    }
                    be.setServed(head);
                    be.phase = PHASE_ARRIVING;
                }
            }
            case PHASE_ARRIVING -> {
                class_1688 head = be.resolveServed(sw);
                if (head == null) { be.resetService(); return; }
                CruiseController.suppress(head, sw, 5); // 进站期间抑制巡航自驱，允许减速
                double cx = pos.method_10263() + 0.5D, cz = pos.method_10260() + 0.5D;
                double dx = cx - head.method_23317(), dz = cz - head.method_23321();
                double dist = Math.hypot(dx, dz);
                if (dist < ALIGN_DIST && horizontalSpeed(head) < 0.03D) {
                    // 精准停靠：对齐站台中心
                    head.method_18799(class_243.field_1353);
                    head.field_6037 = true;
                    head.method_24203(cx, head.method_23318(), cz);
                    be.phase = PHASE_DWELLING;
                    be.dwellTicksLeft = be.getStopTicks();
                    if (be.programMode) {
                        be.fireEvent("arrive", sw); // 编程模式：由程序决定开关门等
                    } else {
                        be.setDoorsOpen(sw, pos, true);
                    }
                } else {
                    // 平滑减速 + 朝中心微调
                    class_243 v = head.method_18798();
                    head.method_18800(v.field_1352 * 0.6D + dx * 0.05D, v.field_1351, v.field_1350 * 0.6D + dz * 0.05D);
                    head.field_6037 = true;
                }
            }
            case PHASE_DWELLING -> {
                class_1688 head = be.resolveServed(sw);
                if (head != null) {
                    CruiseController.suppress(head, sw, 5); // 停靠期间抑制巡航自驱
                    head.method_18799(class_243.field_1353);
                    head.field_6037 = true;
                }
                be.dwellTicksLeft--;
                if (!be.programMode && be.dwellTicksLeft == WARN_TICKS) {
                    // 默认模式：发车前 3 秒关门 + 提示音（编程模式交给程序）
                    be.setDoorsOpen(sw, pos, false);
                    sw.method_8396(null, pos, class_3417.field_14622.comp_349(),
                            class_3419.field_15245, 1.0F, 2.0F);
                }
                if (be.dwellTicksLeft <= 0) {
                    if (be.programMode) {
                        be.fireEvent("depart", sw);
                    } else {
                        be.setDoorsOpen(sw, pos, false);
                    }
                    be.phase = PHASE_DEPARTING;
                    be.departTicks = 0;
                    if (be.turnback) {
                        // 折返站：把发车方向反转 180°，让列车头倒着开、后车借连挂物理自然跟随（无需环形轨道）
                        be.dirX = -be.dirX;
                        be.dirZ = -be.dirZ;
                    }
                    if (head != null) {
                        ((AttachmentTarget) head).setAttached(ModAttachments.CRUISE_SPEED, be.getCruiseSpeedPerTick());
                    }
                }
            }
            case PHASE_DEPARTING -> {
                class_1688 head = be.resolveServed(sw);
                if (head == null) { be.resetService(); return; }
                be.departTicks++;
                double target = be.getCruiseSpeedPerTick();
                double next = Math.min(target, horizontalSpeed(head) + be.acceleration);
                head.method_18800(be.dirX * next, head.method_18798().field_1351, be.dirZ * next);
                head.field_6037 = true;

                double dx = (pos.method_10263() + 0.5D) - head.method_23317();
                double dz = (pos.method_10260() + 0.5D) - head.method_23321();
                if (Math.hypot(dx, dz) > 1.6D || be.departTicks > 200) {
                    be.resetService();
                    be.cooldown = COOLDOWN_TICKS;
                }
            }
            default -> be.phase = PHASE_IDLE;
        }
    }

    private static double horizontalSpeed(class_1688 cart) {
        class_243 v = cart.method_18798();
        return Math.hypot(v.field_1352, v.field_1350);
    }

    /** 找到正上方铁轨格内的“列车头”（无跟随目标的车厢）。 */
    private class_1688 findHeadAbove(class_3218 world, class_2338 railPos) {
        class_238 box = new class_238(railPos).method_1009(0.4D, 0.6D, 0.4D);
        List<class_1688> carts = world.method_8390(class_1688.class, box, c -> true);
        for (class_1688 c : carts) {
            if (((AttachmentTarget) c).getAttached(ModAttachments.FOLLOW_TARGET) == null) {
                return c;
            }
        }
        return null;
    }

    private void setServed(class_1688 cart) {
        UUID id = cart.method_5667();
        servedMost = id.getMostSignificantBits();
        servedLeast = id.getLeastSignificantBits();
    }

    private class_1688 resolveServed(class_3218 world) {
        if (servedMost == 0L && servedLeast == 0L) {
            return null;
        }
        class_1297 e = world.method_14190(new UUID(servedMost, servedLeast));
        return (e instanceof class_1688 cart && !cart.method_31481()) ? cart : null;
    }

    private void resetService() {
        phase = PHASE_IDLE;
        servedMost = 0L;
        servedLeast = 0L;
        dwellTicksLeft = 0;
        departTicks = 0;
    }

    /** 开/关站台周围的现代屏蔽门。 */
    private void setDoorsOpen(class_3218 world, class_2338 center, boolean open) {
        class_2338.class_2339 p = new class_2338.class_2339();
        for (int dx = -DOOR_SCAN_RADIUS; dx <= DOOR_SCAN_RADIUS; dx++) {
            for (int dz = -DOOR_SCAN_RADIUS; dz <= DOOR_SCAN_RADIUS; dz++) {
                for (int dy = 0; dy <= 2; dy++) {
                    p.method_10103(center.method_10263() + dx, center.method_10264() + dy, center.method_10260() + dz);
                    class_2680 s = world.method_8320(p);
                    if (s.method_27852(ModBlocks.SCREEN_DOOR)
                            && s.method_11654(class_2741.field_12533) == class_2756.field_12607) {
                        ScreenDoorBlock.setOpen(world, p.method_10062(), open);
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------------
    // NBT 持久化
    // ------------------------------------------------------------------
    @Override
    protected void method_11007(class_2487 nbt, class_7225.class_7874 registries) {
        super.method_11007(nbt, registries);
        nbt.method_10569("StopSeconds", stopSeconds);
        nbt.method_10549("Acceleration", acceleration);
        nbt.method_10549("CruiseSpeed", cruiseSpeed);
        nbt.method_10556("Turnback", turnback);
        nbt.method_10569("SelectedParam", selectedParam);
        nbt.method_10569("Phase", phase);
        nbt.method_10544("ServedMost", servedMost);
        nbt.method_10544("ServedLeast", servedLeast);
        nbt.method_10569("DwellTicksLeft", dwellTicksLeft);
        nbt.method_10569("DepartTicks", departTicks);
        nbt.method_10569("Cooldown", cooldown);
        nbt.method_10549("DirX", dirX);
        nbt.method_10549("DirZ", dirZ);
        nbt.method_10582("Program", program);
        nbt.method_10556("ProgramMode", programMode);
        class_2487 bn = new class_2487();
        for (Map.Entry<String, Binding> e : bindings.entrySet()) {
            class_2487 one = new class_2487();
            one.method_10582("Kind", e.getValue().kind());
            one.method_10544("Pos", e.getValue().pos().method_10063());
            bn.method_10566(e.getKey(), one);
        }
        nbt.method_10566("Bindings", bn);
    }

    @Override
    protected void method_11014(class_2487 nbt, class_7225.class_7874 registries) {
        super.method_11014(nbt, registries);
        stopSeconds = class_3532.method_15340(nbt.method_10550("StopSeconds"), 0, 60);
        acceleration = class_3532.method_15350(nbt.method_10574("Acceleration"), 0.005D, 0.20D);
        cruiseSpeed = class_3532.method_15350(nbt.method_10574("CruiseSpeed"), 4.0D, 40.0D);
        turnback = nbt.method_10577("Turnback");
        selectedParam = class_3532.method_15340(nbt.method_10550("SelectedParam"), 0, 3);
        phase = class_3532.method_15340(nbt.method_10550("Phase"), 0, 3);
        servedMost = nbt.method_10537("ServedMost");
        servedLeast = nbt.method_10537("ServedLeast");
        dwellTicksLeft = Math.max(0, nbt.method_10550("DwellTicksLeft"));
        departTicks = Math.max(0, nbt.method_10550("DepartTicks"));
        cooldown = Math.max(0, nbt.method_10550("Cooldown"));
        dirX = nbt.method_10574("DirX");
        dirZ = nbt.method_10574("DirZ");
        program = nbt.method_10558("Program");
        programMode = nbt.method_10577("ProgramMode");
        bindings.clear();
        class_2487 bn = nbt.method_10562("Bindings");
        for (String key : bn.method_10541()) {
            class_2487 one = bn.method_10562(key);
            bindings.put(key, new Binding(one.method_10558("Kind"), class_2338.method_10092(one.method_10537("Pos"))));
        }
        compile();
    }
}
