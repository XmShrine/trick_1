package com.vanillaplus.metro.block.entity;

import com.vanillaplus.metro.VanillaPlusMetro;
import com.vanillaplus.metro.program.Actuators;
import com.vanillaplus.metro.program.CallGuard;
import com.vanillaplus.metro.program.ProgramContext;
import com.vanillaplus.metro.program.ProgramHolder;
import com.vanillaplus.metro.program.ProgrammableController;
import com.vanillaplus.metro.program.ScriptException;
import com.vanillaplus.metro.registry.ModBlockEntities;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_3218;
import net.minecraft.class_3532;
import net.minecraft.class_7225;
import net.minecraft.class_7923;

/**
 * 5 出 1 入可编程红石块的方块实体。
 *  - FACING（方块状态）= 输入面；其余 5 面为输出。
 *  - 事件：on redstone（输入变化）、on tick(N)。
 *  - 程序 API：input()（输入面强度）、out["north"..]=0..15（设某输出面强度）、has/time/log。
 */
public class RedstoneLogicBlockEntity extends class_2586 implements ProgrammableController {

    private final ProgramHolder holder = new ProgramHolder();
    private final int[] outputs = new int[6]; // 按 Direction.ordinal()
    private int lastInput = -1;

    public RedstoneLogicBlockEntity(class_2338 pos, class_2680 state) {
        super(ModBlockEntities.REDSTONE_LOGIC, pos, state);
    }

    // ---- ProgrammableController ----
    @Override public String getProgram() { return holder.getProgram(); }
    @Override public String setProgram(String s) { String e = holder.setProgram(s); method_5431(); return e; }
    @Override public void setProgramMode(boolean m) { holder.setMode(m); method_5431(); }
    @Override public void addBinding(String n, String k, class_2338 p) { holder.addBinding(n, k, p); method_5431(); }

    @Override
    public void runEvent(String event) {
        if (method_10997() instanceof class_3218 sw) {
            class_2350 f = method_11010().method_11654(class_2741.field_12525);
            fireEvent(event, sw, readInput(sw, method_11016(), f), f, method_11010());
        }
    }

    @Override
    public java.util.List<String> apiCatalog() {
        java.util.List<String> l = new java.util.ArrayList<>(java.util.List.of(
                "redstone", "tick", "input", "time", "has", "log", "call", "out", "signal", "switch"));
        l.addAll(holder.bindingNames());
        return l;
    }

    @Override
    public String bindingsInfo() {
        return holder.bindingsInfo();
    }

    /** 某输出面当前强度（0-15）。 */
    public int getOutput(class_2350 face) { return outputs[face.ordinal()]; }

    // ------------------------------------------------------------------
    public static void serverTick(class_1937 world, class_2338 pos, class_2680 state, RedstoneLogicBlockEntity be) {
        if (!(world instanceof class_3218 sw)) {
            return;
        }
        class_2350 inputFace = state.method_11654(class_2741.field_12525);
        int in = readInput(sw, pos, inputFace);

        if (be.holder.isMode() && be.holder.hasProgram()) {
            int iv = be.holder.tickInterval();
            if (iv > 0 && sw.method_8510() % iv == 0) {
                be.fireEvent("tick", sw, in, inputFace, state);
            }
        }
        if (in != be.lastInput) {
            be.lastInput = in;
            if (be.holder.isMode()) {
                be.fireEvent("redstone", sw, in, inputFace, state);
            }
        }
    }

    private void fireEvent(String event, class_3218 world, int input, class_2350 inputFace, class_2680 state) {
        String err = holder.run(event, new Ctx(world, input, inputFace));
        if (err != null) {
            VanillaPlusMetro.LOGGER.warn("[红石块程序 {}] 事件 {} 出错：{}", field_11867.method_23854(), event, err);
        }
        world.method_8452(field_11867, state.method_26204()); // 把新输出推给邻居
        method_5431();
    }

    private static int readInput(class_3218 world, class_2338 pos, class_2350 inputFace) {
        return world.method_49808(pos.method_10093(inputFace), inputFace);
    }

    /** DSL 与本红石块的对接。 */
    private final class Ctx implements ProgramContext {
        private final class_3218 world;
        private final int input;
        private final class_2350 inputFace;
        Ctx(class_3218 world, int input, class_2350 inputFace) { this.world = world; this.input = input; this.inputFace = inputFace; }

        @Override
        public void action(String kind, String name, String method) throws ScriptException {
            throw new ScriptException(0, "红石块不支持资源动作 " + kind + "[..]." + method);
        }

        @Override
        public void assign(String kind, String name, Object value) throws ScriptException {
            if (kind.equals("out")) {
                class_2350 d = class_2350.method_10168(name.toLowerCase());
                if (d == null) {
                    throw new ScriptException(0, "未知输出面 \"" + name + "\"");
                }
                if (d == inputFace) {
                    throw new ScriptException(0, "面 " + name + " 是输入面，不能作输出");
                }
                long v = value instanceof Number n ? n.longValue() : 0;
                outputs[d.ordinal()] = (int) class_3532.method_53062(v, 0, 15);
                return;
            }
            // 命名资源（信号灯 / 道岔）——需先用绑定工具绑到本块
            ProgramHolder.Binding b = holder.binding(name);
            if (b != null && kind.equals("signal") && b.kind().equals("signal")) {
                Actuators.setSignal(world, b.pos(), String.valueOf(value));
            } else if (b != null && kind.equals("switch") && b.kind().equals("switch")) {
                Actuators.setSwitch(world, b.pos(), String.valueOf(value));
            } else {
                throw new ScriptException(0, "红石块不支持写 " + kind + "[\"" + name + "\"]（out 或已绑定的 signal/switch）");
            }
        }

        @Override
        public Object query(String kind, String name, String prop) throws ScriptException {
            throw new ScriptException(0, "红石块暂不支持查询 " + kind + "[..]." + prop);
        }

        @Override
        public Object function(String fn, Object[] a) throws ScriptException {
            switch (fn) {
                case "input": return (long) input;
                case "time": return world.method_8532() % 24000L;
                case "has": {
                    if (a.length < 4) throw new ScriptException(0, "has 需要 4 个参数");
                    class_2338 p = field_11867.method_10069((int) num(a[0]), (int) num(a[1]), (int) num(a[2]));
                    String want = String.valueOf(a[3]);
                    if (!want.contains(":")) want = "minecraft:" + want;
                    return class_7923.field_41175.method_10221(world.method_8320(p).method_26204()).toString().equals(want);
                }
                case "log": VanillaPlusMetro.LOGGER.info("[红石块程序 {}] {}", field_11867.method_23854(), a.length > 0 ? a[0] : ""); return null;
                case "call": {
                    ProgramHolder.Binding b = holder.binding(String.valueOf(a.length > 0 ? a[0] : ""));
                    if (b == null || !b.kind().equals("controller")) {
                        throw new ScriptException(0, "未绑定控制器 \"" + (a.length > 0 ? a[0] : "") + "\"");
                    }
                    if (world.method_8321(b.pos()) instanceof com.vanillaplus.metro.program.ProgrammableController t) {
                        CallGuard.fire(t, String.valueOf(a.length > 1 ? a[1] : ""));
                    }
                    return null;
                }
                default: throw new ScriptException(0, "红石块未知函数 " + fn + "()");
            }
        }

        private long num(Object o) throws ScriptException {
            if (o instanceof Number n) return n.longValue();
            throw new ScriptException(0, "需要数字，得到 " + o);
        }
    }

    // ---- NBT ----
    @Override
    protected void method_11007(class_2487 nbt, class_7225.class_7874 registries) {
        super.method_11007(nbt, registries);
        holder.writeNbt(nbt);
        nbt.method_10539("Outputs", outputs.clone());
    }

    @Override
    protected void method_11014(class_2487 nbt, class_7225.class_7874 registries) {
        super.method_11014(nbt, registries);
        holder.readNbt(nbt);
        int[] o = nbt.method_10561("Outputs");
        if (o.length == 6) {
            System.arraycopy(o, 0, outputs, 0, 6);
        }
    }
}
