package com.vanillaplus.metro.block.entity;

import com.vanillaplus.metro.block.MetroSignalBlock;
import com.vanillaplus.metro.metro.CruiseController;
import com.vanillaplus.metro.metro.RailPathfinder;
import com.vanillaplus.metro.registry.ModAttachments;
import com.vanillaplus.metro.registry.ModBlockEntities;
import com.vanillaplus.metro.registry.ModBlocks;
import net.fabricmc.fabric.api.attachment.v1.AttachmentTarget;
import net.minecraft.class_1688;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_3218;
import net.minecraft.class_7225;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * 现代信号灯的方块实体：基于“区间占用度”的隐形闭塞（特性·信号系统）。
 *
 * 逻辑内核：
 *  - 信号灯守护旁边最近的一段铁轨（guardedRail），并朝其 FACING 方向界定一个“区间”——
 *    从守护点沿轨道向前，直到下一个站台或到达上限为止。
 *  - 若区间内存在矿车（被占用）→ 红灯（LIT=false），并对信号后方逼近的列车头强行接管物理、平滑减速停在信号前。
 *  - 区间空闲 → 绿灯（LIT=true），放行；对停在信号前的列车头给一个前向初速使其重新起步。
 *  - 红灯时向外输出红石信号（见 MetroSignalBlock）。
 */
public class MetroSignalBlockEntity extends class_2586 {

    private static final int RECOMPUTE_INTERVAL = 5;   // 每 5 tick 重算一次占用
    private static final int SECTION_MAX = 24;         // 区间最大轨道段数
    private static final int RAIL_SEARCH_RADIUS = 2;   // 守护铁轨搜索半径
    private static final double BRAKE_DISTANCE = 5.0D;  // 信号前多少格开始接管制动
    private static final double DEFAULT_LAUNCH = 0.3D;  // 绿灯放行的默认起步速度（格/tick）

    private class_2338 guardedRail = null;
    private int tickCounter = 0;
    /** 手动模式：被程序 signal["名"]=.. 设定后，停止自动占用检测，红绿由程序决定。 */
    private boolean manual = false;

    public MetroSignalBlockEntity(class_2338 pos, class_2680 state) {
        super(ModBlockEntities.METRO_SIGNAL, pos, state);
    }

    public class_2338 getGuardedRail() {
        return guardedRail;
    }

    /** 供程序调用：切到手动并设红/绿（true=绿）。 */
    public void setManual(boolean green) {
        this.manual = true;
        method_5431();
        if (method_10997() != null && method_11010().method_11654(class_2741.field_12548) != green) {
            method_10997().method_8652(field_11867, method_11010().method_11657(class_2741.field_12548, green), class_2248.field_31036);
        }
    }

    public static void serverTick(class_1937 world, class_2338 pos, class_2680 state, MetroSignalBlockEntity be) {
        if (!(world instanceof class_3218 sw)) {
            return;
        }
        // 守护铁轨（缓存；失效则重新搜索）
        if (be.guardedRail == null || !RailPathfinder.isRail(sw, be.guardedRail)) {
            be.guardedRail = RailPathfinder.findNearbyRail(sw, pos, RAIL_SEARCH_RADIUS);
        }
        if (be.guardedRail == null) {
            return; // 附近没有铁轨，不工作
        }

        class_2350 facing = state.method_11654(class_2741.field_12481);

        // 每隔若干 tick 重算区间占用，并更新红绿灯
        boolean lit = state.method_11654(class_2741.field_12548);
        if (!be.manual && ++be.tickCounter % RECOMPUTE_INTERVAL == 0) {
            boolean occupied = be.isSectionOccupied(sw, be.guardedRail, facing);
            boolean newLit = !occupied;
            if (newLit != lit) {
                lit = newLit;
                sw.method_8652(pos, state.method_11657(class_2741.field_12548, lit), class_2248.field_31036);
            }
        }

        // 每 tick 根据红/绿对信号前的列车头做制动 / 放行
        be.controlApproachingTrains(sw, be.guardedRail, facing, lit);
    }

    /** 沿 FACING 方向界定“区间”并检测其中是否有矿车。守护点自身被封锁以防止向后泄漏。 */
    private boolean isSectionOccupied(class_3218 world, class_2338 rail, class_2350 facing) {
        class_2338 ahead = firstRailInDir(world, rail, facing);
        if (ahead == null) {
            return false;
        }
        Set<class_2338> visited = new HashSet<>();
        visited.add(rail);   // 封锁守护点，避免 BFS 绕回信号后方
        visited.add(ahead);
        Deque<class_2338> queue = new ArrayDeque<>();
        queue.add(ahead);
        List<class_2338> section = new ArrayList<>();

        while (!queue.isEmpty() && section.size() < SECTION_MAX) {
            class_2338 cur = queue.poll();
            section.add(cur);
            // 到达站台即为区间边界，不再向前扩展
            if (world.method_8320(cur.method_10074()).method_27852(ModBlocks.PLATFORM_CORE)) {
                continue;
            }
            for (class_2338 n : RailPathfinder.neighborsOf(world, cur)) {
                if (visited.add(n)) {
                    queue.add(n);
                }
            }
        }
        return anyMinecartOn(world, section);
    }

    private static boolean anyMinecartOn(class_3218 world, List<class_2338> rails) {
        if (rails.isEmpty()) {
            return false;
        }
        int minX = Integer.MAX_VALUE, minY = Integer.MAX_VALUE, minZ = Integer.MAX_VALUE;
        int maxX = Integer.MIN_VALUE, maxY = Integer.MIN_VALUE, maxZ = Integer.MIN_VALUE;
        Set<class_2338> set = new HashSet<>(rails);
        for (class_2338 p : rails) {
            minX = Math.min(minX, p.method_10263()); maxX = Math.max(maxX, p.method_10263());
            minY = Math.min(minY, p.method_10264()); maxY = Math.max(maxY, p.method_10264());
            minZ = Math.min(minZ, p.method_10260()); maxZ = Math.max(maxZ, p.method_10260());
        }
        class_238 box = new class_238(minX, minY, minZ, maxX + 1, maxY + 2, maxZ + 1);
        List<class_1688> carts =
                world.method_8390(class_1688.class, box, c -> true);
        for (class_1688 c : carts) {
            class_2338 bp = c.method_24515();
            if (set.contains(bp) || set.contains(bp.method_10074())) {
                return true;
            }
        }
        return false;
    }

    /** 红灯：对信号后方逼近的列车头减速停车；绿灯：给停在信号前的列车头一个前向初速放行。 */
    private void controlApproachingTrains(class_3218 world, class_2338 rail, class_2350 facing, boolean lit) {
        class_243 fv = new class_243(facing.method_10148(), 0.0D, facing.method_10165());
        // 停车线：守护铁轨前 1 格（信号后方一侧）
        class_243 stopPoint = class_243.method_24953(rail).method_1020(fv.method_1021(1.0D));

        class_238 area = new class_238(stopPoint, stopPoint).method_1009(BRAKE_DISTANCE, 1.6D, BRAKE_DISTANCE);
        List<class_1688> carts = world.method_8390(
                class_1688.class, area,
                c -> ((AttachmentTarget) c).getAttached(ModAttachments.FOLLOW_TARGET) == null); // 只管列车头

        for (class_1688 cart : carts) {
            class_243 toStop = stopPoint.method_1020(cart.method_19538());
            double along = toStop.method_1026(fv); // >0：车在停车线后方（正在逼近）
            class_243 v = cart.method_18798();

            if (!lit) {
                // 红灯：仅对朝信号方向前进、且尚未越过停车线的车减速
                boolean movingToward = v.method_1026(fv) > 0.0D;
                if (along > -0.1D && movingToward) {
                    CruiseController.suppress(cart, world, 5); // 红灯制动期间抑制巡航自驱
                    double allowed = Math.max(0.0D, along * 0.25D); // 越近越慢
                    double sp = Math.min(horizontalSpeed(cart), allowed);
                    cart.method_18800(fv.field_1352 * sp, v.field_1351, fv.field_1350 * sp);
                    cart.field_6037 = true;
                }
            } else {
                // 绿灯：把停在信号附近、几乎静止的列车头重新推起来
                if (Math.abs(along) < 1.5D && horizontalSpeed(cart) < 0.05D) {
                    Double cruise = ((AttachmentTarget) cart).getAttached(ModAttachments.CRUISE_SPEED);
                    double launch = (cruise != null && cruise > 0.0D) ? Math.min(cruise, DEFAULT_LAUNCH) : DEFAULT_LAUNCH;
                    cart.method_18800(fv.field_1352 * launch, v.field_1351, fv.field_1350 * launch);
                    cart.field_6037 = true;
                }
            }
        }
    }

    private static class_2338 firstRailInDir(class_1937 world, class_2338 rail, class_2350 dir) {
        class_2338 flat = rail.method_10093(dir);
        if (RailPathfinder.isRail(world, flat)) return flat.method_10062();
        if (RailPathfinder.isRail(world, flat.method_10084())) return flat.method_10084();
        if (RailPathfinder.isRail(world, flat.method_10074())) return flat.method_10074();
        return null;
    }

    private static double horizontalSpeed(class_1688 cart) {
        class_243 v = cart.method_18798();
        return Math.hypot(v.field_1352, v.field_1350);
    }

    @Override
    protected void method_11007(class_2487 nbt, class_7225.class_7874 registries) {
        super.method_11007(nbt, registries);
        if (guardedRail != null) {
            nbt.method_10544("GuardedRail", guardedRail.method_10063());
            nbt.method_10556("HasGuardedRail", true);
        }
        nbt.method_10556("Manual", manual);
    }

    @Override
    protected void method_11014(class_2487 nbt, class_7225.class_7874 registries) {
        super.method_11014(nbt, registries);
        guardedRail = nbt.method_10577("HasGuardedRail") ? class_2338.method_10092(nbt.method_10537("GuardedRail")) : null;
        manual = nbt.method_10577("Manual");
    }
}
